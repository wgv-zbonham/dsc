# WatchGuard Asset Library

This repo contains code snippets for the specific application of UI elements. Please view the [GitHub wiki](https://github.com/WatchGuard/assetLibrary/wiki) for UX Design documentation. For general WGUX documentation and support files, refer to the UX Design [repo](https://github.com/WatchGuard/UX-Design) and [wiki](https://github.com/WatchGuard/UX-Design/wiki).

> Do not make changes in the assetLibrary folder in your project. App-specific styling can be made in the appSpecific folder in each project's **asset/scss** folder.

## How to Use assetLibrary in a WatchGuard App

1. Build the *asset* folder and file structure in the app as outlined [here](../../wiki/SCSS).
2. Using a Git command-line tool and navigate to your repo/branch and clone assetLibrary into a new *assetLibrary* folder by enter the following command: `` git submodule add https://github.com/WatchGuard/assetLibrary.git [path to app web root]/assetLibrary ``.  The path to the app web root should be the same folder the *asset* directory is in.
3. In Visual Studio, include the newly-created *assetLibrary* folder in the project.
4. Create or modify the *app.scss* file to only contain the following. First, import *scss/library.scss*. Then, import any app-specific scss files. See below for an example *app.scss* file.
5. Modify your loader or bundle config file to include *assets/scss/app.css* only. No other css file is required
 
The only file the app needs to reference for styling is the compiled *app.css*.

#### Sample *app.scss* file

The *app.scss* file only needs to contain 2 imports. First, the assetLibrary is imported using *library.scss*. Then, app-specific style sheets are loaded.

```
@import '../../assetLibrary/scss/library';
@import 'appSpecific/admin';
```

### Updating to Latest assetLibrary Version

Updating to the latest version of assetLibrary can be done with one command from within your project's git repo location (NOT the submodule location):

```git submodule update --remote assetLibrary```

This will pull any assetLibrary repo changes to your local project. 

> Note: it's good practice to check your *assetLibrary* folder in Visual Studio for any new (hidden) files that need to be added to your project.

In addition, this will update the submodule commit pointer to the latest commit (see About Submodules below). You will need to commit/pull/push this to your project repo.

### About Submodules

Adding a submodule creates a new .gitmodules file. This is a configuration file that stores the mapping between the project’s URL and the local subdirectory you’ve pulled it into. This file is version-controlled with your other files and is pushed/pulled with the rest of the project. This is how Git knows where to get the submodule projects from.
 
For more information about Git submodules, [click here](https://git-scm.com/book/en/v2/Git-Tools-Submodules).