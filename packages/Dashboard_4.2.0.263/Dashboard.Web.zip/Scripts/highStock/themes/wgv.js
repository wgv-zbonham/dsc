/**
 * Custom Wachguard theme for Highcharts JS
 * @author Jason Clemens
 */

Highcharts.theme = {
    colors: ["#0579D9", "#e5a800", "#a85c00", "#8d2c9f", "#29a600", "#de1e21"],
    chart: {
        backgroundColor: null,
        borderColor: '#EEEFF2',
        className: 'chart-container',
        style: {
            fontFamily: 'Roboto, Verdana, sans-serif',
            fonSize: '12pt'
        }
    },
    xAxis: {
        gridLineColor: '#DDE1E5',
        gridLineWidth: 1,
        labels: {
            style: {
                color: '#5D6672'
            }
        },
        lineColor: '#DDE1E5',
        tickColor: '#DDE1E5',
        title: {
            style: {
                color: '#CCC',
            }
        }
    },
    yAxis: {
        gridLineColor: '#DDE1E5',
        labels: {
            style: {
                color: '#5D6672'
            }
        },
        lineColor: '#A0A0A0',
        tickColor: '#DDE1E5',
        title: {
            style: {
                color: '#CCC',
            }
        }
    },
    tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.75)',
        style: {
            color: '#F0F0F0'
        }
    },
    toolbar: {
        itemStyle: {
            color: 'silver'
        }
    },
    plotOptions: {
        areaspline: {
            marker: { enabled: false },
            line: { lineWidth: 1 }
        },
        line: {
            dataLabels: {
                color: '#CCC'
            },
            marker: {
                lineColor: '#333'
            }
        },
        spline: {
            marker: {
                lineColor: '#333'
            }
        },
        scatter: {
            marker: {
                lineColor: '#333'
            }
        },
        candlestick: {
            lineColor: 'white'
        }
    },
    legend: {
        itemStyle: {
            font: '9pt Roboto, Verdana, sans-serif',
            color: '#A0A0A0'
        },
        itemHoverStyle: {
            color: '#FFF'
        },
        itemHiddenStyle: {
            color: '#444'
        }
    },
    credits: {
        enabled: false,
    },
    labels: {
        style: {
            color: '#CCC'
        }
    },

    navigation: {
        buttonOptions: {
            symbolStroke: '#929AA5',
            hoverSymbolStroke: '#FFFFFF',
            theme: {
                r: 4,
                states: {
                    hover: {
                        stroke: 'none',
                        fill: '#075FA6'
                    },
                    select: {
                        stroke: 'none',
                        fill: {
                            linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                            stops: [
                                [0.1, '#e5a800'],
                                [0.9, '#F7CF1F']
                            ]
                        },
                    }
                }
            },
            x: 0,
            y: 0
        }
    },

    // scroll charts
    rangeSelector: {
        buttonTheme: {
            fill: {
                linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                stops: [
					[0.4, '#888'],
					[0.6, '#555']
                ]
            },
            stroke: '#000000',
            style: {
                color: '#CCC',
                fontWeight: 'bold'
            },
            states: {
                hover: {
                    fill: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
							[0.4, '#BBB'],
							[0.6, '#888']
                        ]
                    },
                    stroke: '#000000',
                    style: {
                        color: 'white'
                    }
                },
                select: {
                    fill: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
							[0.1, '#000'],
							[0.3, '#333']
                        ]
                    },
                    stroke: '#000000',
                    style: {
                        color: 'yellow'
                    }
                }
            }
        },
        inputStyle: {
            backgroundColor: '#333',
            color: 'silver'
        },
        labelStyle: {
            color: 'silver'
        }
    },

    navigator: {
        handles: {
            backgroundColor: '#666',
            borderColor: '#AAA'
        },
        outlineColor: '#CCC',
        maskFill: 'rgba(16, 16, 16, 0.5)',
        series: {
            color: '#7798BF',
            lineColor: '#A6C7ED'
        }
    },

    scrollbar: {
        barBackgroundColor: {
            linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
            stops: [
                [0.4, '#888'],
                [0.6, '#555']
            ]
        },
        barBorderColor: '#CCC',
        buttonArrowColor: '#CCC',
        buttonBackgroundColor: {
            linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
            stops: [
                [0.4, '#888'],
                [0.6, '#555']
            ]
        },
        buttonBorderColor: '#CCC',
        rifleColor: '#FFF',
        trackBackgroundColor: {
            linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
            stops: [
				[0, '#000'],
				[1, '#333']
            ]
        },
        trackBorderColor: '#666'
    },

    // special colors
    legendBackgroundColor: 'rgba(0, 0, 0, 0.5)',
    background2: 'rgb(35, 35, 70)',
    dataLabelsColor: '#444',
    textColor: '#C0C0C0',
    maskColor: 'rgba(255,255,255,0.3)'
};

// Apply the theme
var highchartsOptions = Highcharts.setOptions(Highcharts.theme);
