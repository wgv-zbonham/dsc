﻿(function (dashboard) {
    dashboard.config = function () {
        return {
            logUnhandledErrors: true,
            sessionTimeout: 30,
            enableDebugMode: false,
            //pathToElWeb: "http://localhost:55596",
            //pathToDashboard: "http://localhost:55389"
            pathToElWeb: "https://eldashdev01",
            pathToDashboard: "http://eldashdev01:8080"
        };
    }();
})(window.dashboard = window.dashboard || {});
