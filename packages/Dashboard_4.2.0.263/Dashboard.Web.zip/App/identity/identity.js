// ReSharper disable InconsistentNaming
define(["require", "exports", 'durandal/system'], function (require, exports, system) {
    var Identity = (function () {
        function Identity() {
        }
        Identity.prototype.initialize = function () {
            var def = $.Deferred();
            $.get('/api/claim')
                .done(function (result) {
                Identity.claims = Identity.toKeys(result);
                system.log("Identity initialized");
                def.resolve(true);
            })
                .fail(function (data) {
                console.error('Op Failure (' + status + '): ' + JSON.stringify(data));
                def.resolve(false);
            });
            return def.promise();
        };
        Identity.prototype.hasAllClaims = function (claims) {
            // short circuit if we are an administrator
            if (Identity.claims[Identity.administratorClaim] != null) {
                return true;
            }
            return claims.every(function (claim) {
                return (Identity.claims[claim.toUpperCase()] != null);
            });
        };
        Identity.prototype.hasClaim = function (claims) {
            if (Identity.claims[Identity.administratorClaim] != null) {
                return true;
            }
            return claims.some(function (claim) {
                return (Identity.claims[claim.toUpperCase()] != null);
            });
        };
        Identity.toKeys = function (claims) {
            var permissions = {};
            for (var i = 0; i < claims.length; i++) {
                permissions[claims[i].name.toUpperCase()] = claims[i];
            }
            return permissions;
        };
        Identity.claims = {};
        Identity.administratorClaim = "ADMINISTRATOR";
        return Identity;
    })();
    exports.identity = new Identity;
});
//# sourceMappingURL=identity.js.map