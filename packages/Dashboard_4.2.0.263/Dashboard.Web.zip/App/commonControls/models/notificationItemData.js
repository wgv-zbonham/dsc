define(["require", "exports", 'uiServices/notificationLevel'], function (require, exports, notificationLevel) {
    var NotificationItemData = (function () {
        function NotificationItemData(message, notifLevel, callback) {
            this.level = notifLevel || notificationLevel.NotificationLevel.general;
            this.message = message;
            this.callback = callback;
            this.timeOut = 3000; // default is 3s
        }
        return NotificationItemData;
    })();
    exports.NotificationItemData = NotificationItemData;
});
//# sourceMappingURL=notificationItemData.js.map