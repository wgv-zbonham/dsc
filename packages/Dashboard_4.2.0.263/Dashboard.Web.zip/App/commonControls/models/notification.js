define(["require", "exports", 'knockout', 'uiServices/notificationLevelMapper'], function (require, exports, ko, cssMapper) {
    var timerId = 0;
    var vm = {
        messages: ko.observableArray([]),
        show: function (value) {
            // clear out the messages;
            vm.messages([]);
            var itemData = value;
            var timeOut = itemData.timeOut;
            if (_.isArray(itemData.message)) {
                vm.messages(itemData.message);
                var count = itemData.message.slice(2, itemData.message.length).length;
                timeOut += (count * 500);
            }
            else {
                vm.messages.push(itemData.message);
            }
            var el = $('#system-msg');
            if (itemData.callback) {
                itemData.callback(el, true);
            }
            vm.display(itemData.level);
            if (timeOut > 1) {
                timerId = window.setTimeout(function () {
                    vm.hide();
                    if (itemData.callback) {
                        itemData.callback(el, false);
                    }
                }, timeOut);
            }
            else {
                timerId = -1;
            }
        },
        hide: function () {
            $('#system-msg').slideUp();
            if (timerId > 0) {
                window.clearTimeout(timerId);
            }
        },
        display: function (level) {
            vm.hide();
            var el = $('#system-msg');
            el.removeClass().addClass("show " + cssMapper.CSSMap(level)).slideDown();
        }
    };
    return vm;
});
//# sourceMappingURL=notification.js.map