define(["require", "exports", 'durandal/system', 'durandal/app', 'knockout', 'commonControls/models/notificationItemData', 'commonControls/models/notification'], function (require, exports, system, app, ko, notificationData, notification) {
    var NotificationSingleton = (function () {
        function NotificationSingleton() {
            if (NotificationSingleton.instance) {
                throw new Error("Error: Instantiation failed: Use NotificationSingleton.getInstance() instead of new.");
            }
            NotificationSingleton.instance = this;
        }
        NotificationSingleton.getInstance = function () {
            return NotificationSingleton.instance;
        };
        NotificationSingleton.prototype.hasLastNotification = function () {
            return this.lastNotification;
        };
        NotificationSingleton.prototype.setLastNofication = function (value) {
            this.lastNotification = value;
        };
        NotificationSingleton.prototype.getLastNotification = function () {
            return this.lastNotification;
        };
        NotificationSingleton.instance = new NotificationSingleton();
        return NotificationSingleton;
    })();
    exports.NotificationSingleton = NotificationSingleton;
    var NotificationService = (function () {
        function NotificationService(context, callback) {
            this.defaultModel = 'commonControls/viewmodels/genericDialogViewModel';
            if (document.addEventListener) {
                document.addEventListener("visibilitychange", function () {
                    if (NotificationSingleton.getInstance().hasLastNotification()) {
                        var lastNotification = NotificationSingleton.getInstance().getLastNotification();
                        lastNotification();
                    }
                });
            }
            // add single message to message(s) array if there isnt any messages already
            if (!context.messages) {
                context.messages = [context.message];
            }
            if (!context.buttons) {
                context.buttons = [{ 'label': 'Ok' }];
            }
            this.context = context;
            if (!ko.isObservable(context.viewModel)) {
                this.viewModel = ko.viewmodel.fromModel(context.viewModel);
            }
            this.context.NotificationService = this;
            this.context.viewModel = this.viewModel;
            this.context.templateUrl = context.templateUrl;
            this.callback = callback;
        }
        NotificationService.prototype.show = function () {
            if (!document.hidden) {
                NotificationSingleton.getInstance().setLastNofication(null);
                if (this.context.messages.length) {
                    system.log(this.context.messages[0]);
                }
                return app.showDialog(this.context.model || this.defaultModel, this.context);
            }
            else {
                var self = this;
                var deferred = $.Deferred();
                NotificationSingleton.getInstance().setLastNofication(function () {
                    return self.show();
                });
                return deferred.promise();
            }
        };
        NotificationService.prototype.showToast = function () {
            if (document.hidden) {
                return;
            }
            NotificationSingleton.getInstance().setLastNofication(null);
            notification.show(new notificationData.NotificationItemData(this.context.message, this.context.notificationLevel));
        };
        NotificationService.prototype.canCloseDialog = function (viewModel, selectedButton) {
            if (this.callback) {
                return this.callback(viewModel, selectedButton);
            }
            return true;
        };
        return NotificationService;
    })();
    exports.NotificationService = NotificationService;
});
//# sourceMappingURL=notificationService.js.map