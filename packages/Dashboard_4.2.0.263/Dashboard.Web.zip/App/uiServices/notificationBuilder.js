define(["require", "exports", 'uiServices/notificationService', 'uiServices/notificationLevel'], function (require, exports, notificationService, notificationLevel) {
    var notificationBuilder = {
        buildSuccessToast: function (message) {
            notificationBuilder.buildNotificationToast('Success', message, notificationLevel.NotificationLevel.success);
        },
        buildAlertToast: function (message) {
            notificationBuilder.buildNotificationToast('Alert', message, notificationLevel.NotificationLevel.alert);
        },
        buildErrorToast: function (message) {
            notificationBuilder.buildNotificationToast('Error', message, notificationLevel.NotificationLevel.error);
        },
        buildNotificationToast: function (title, message, notifyLevel) {
            var context = {
                message: message,
                notificationLevel: notifyLevel
            };
            var dialog = new notificationService.NotificationService(context);
            dialog.showToast();
        },
        buildConfirmationDialog: function (message) {
            var context = {
                title: 'Confirm',
                message: message,
                notificationLevel: notificationLevel.NotificationLevel.confirm,
                buttons: [{ label: 'No', type: 'secondary' }, { label: 'Yes', type: 'primary' }],
            };
            var dialog = new notificationService.NotificationService(context);
            return dialog.show();
        }
    };
    return notificationBuilder;
});
//# sourceMappingURL=notificationBuilder.js.map