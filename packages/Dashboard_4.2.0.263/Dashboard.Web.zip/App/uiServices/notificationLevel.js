define(["require", "exports"], function (require, exports) {
    (function (NotificationLevel) {
        NotificationLevel[NotificationLevel["general"] = 0] = "general";
        NotificationLevel[NotificationLevel["success"] = 1] = "success";
        NotificationLevel[NotificationLevel["alert"] = 2] = "alert";
        NotificationLevel[NotificationLevel["confirm"] = 3] = "confirm";
        NotificationLevel[NotificationLevel["error"] = 4] = "error"; /* red */
    })(exports.NotificationLevel || (exports.NotificationLevel = {}));
    var NotificationLevel = exports.NotificationLevel;
});
//# sourceMappingURL=notificationLevel.js.map