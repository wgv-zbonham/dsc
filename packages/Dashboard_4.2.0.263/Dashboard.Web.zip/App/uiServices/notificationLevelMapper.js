define(["require", "exports"], function (require, exports) {
    function CSSMap(level) {
        var styles = ['general', 'success', 'alert', 'confirm', 'error'];
        return styles[level];
    }
    exports.CSSMap = CSSMap;
});
//# sourceMappingURL=notificationLevelMapper.js.map