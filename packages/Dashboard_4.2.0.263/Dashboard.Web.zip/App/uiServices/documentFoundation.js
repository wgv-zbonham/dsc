define(["require", "exports"], function (require, exports) {
    var documentFoundation = (function () {
        function documentFoundation() {
        }
        documentFoundation.composed = function () {
            //$('.select').each(function () {
            //    if (!$(this).hasClass('select-searchable')) {
            //        $(this).chosen({ inherit_select_classes: true, disable_search: true });
            //    } else {
            //        $(this).chosen({ inherit_select_classes: true });
            //    }
            //});
        };
        documentFoundation.init = function () {
            var _this = this;
            // wire up 'foundation' to the document DOM
            $(document).foundation({
                accordion: {
                    active_class: 'open'
                },
                equalizer: {
                    // Specify if Equalizer should make elements equal height once they become stacked.
                    equalize_on_stack: true,
                    // Allow equalizer to resize hidden elements
                    act_on_hidden_el: true
                }
            });
            // allow search and navigation menu to collapse when window size is reduced
            $('.left-offcanvas-toggle').click(function () {
                $('.row-offcanvas').toggleClass('search-active');
            });
            $('.right-offcanvas-toggle').click(function () {
                $('.row-offcanvas').toggleClass('menu-active');
            });
            $('.exit-off-canvas').click(function () {
                $('.row-offcanvas').removeClass('menu-active search-active');
            });
            // auto focus input.copy-text, on click, to allow copy/paste more easily
            $('.copy-text').click(function () {
                $(_this).select();
            });
            // reset any select controls to their zero index when cleared
            $('.clear-search-param').on('click', function () {
                var parent = $(this).closest('label'), select = parent.next('.select, .select-searchable');
                select.prop("selectedIndex", 0).trigger("chosen:updated");
                $(this).hide();
            });
            // indicate the select control can be cleared
            $('.sidebar-form .select').on('change', function (e) {
                $(this).trigger('chosen:updated');
                $(this).prev('label').find('.clear-search-param').show();
            });
        };
        return documentFoundation;
    })();
    return documentFoundation;
});
//# sourceMappingURL=documentFoundation.js.map