﻿define([], function () {
  var size = function () {
	
	

    var windowHeight = $(window).height(),
        windowWidth = $(window).width(),
        headerHeight = $('#header').outerHeight(),
        contentHeight = windowHeight - headerHeight,
        contentHeaderHeight = $('#content-header').outerHeight(),
        contentFilterHeight = $('#content-filter').outerHeight(),
		searchHeight = $('.search-sidebar-offcanvas').outerHeight() + 200;     
	 	
      // MATCH SIDEBAR HEIGHTS
    var sidebarHeight = 0;
    if (windowWidth < 769) {
        $('.offcanvas-sidebar').each(function () {
            if ($(this).height() > sidebarHeight) {
                sidebarHeight = $(this).height();
            }
        });
        $('.offcanvas-sidebar').css('min-height', sidebarHeight);
    }
    else {
        $('.offcanvas-sidebar').css('min-height', '');
    }

	// height of video, ensure we retain aspect ratio 
	// NOTE: this is relevant for 16:9 video ONLY!!
	// Need to reassess this for Hydra video and maybe implement a flag
	// to toggle the aspect ratio, CSS class or some other method

		//$("#event-video, #video-wrapper > .row > .panel").css('min-height',Math.round(($("#event-video").width()/16)*9) + 15 +'px');
	


	// FIXED HEADER & SIDEBAR
	
	// check to see if the .fix-header class is present on section.main-section
	// IF it is, let's get the position of the #fixed-header
	if( $('.main-section').hasClass('fix-header') ){
	
			
		var fixedHeader = function(){  
		
		var fixedHeaderTop = $('#fixed-header').offset().top,
			windowHeight = $(window).height(),
			windowWidth = $(window).width(),
			searchbarHeight = $('.search-sidebar-offcanvas').outerHeight() + 200,
			scrollTop = $(document).scrollTop();  
			
			// STICKY HEADER & SIDEBAR
			if (scrollTop >= '80' && windowWidth > "1024") { 			
			    $('#content-wrapper').addClass('sticky'); 
			 	if(windowHeight > searchbarHeight){
					$('.search-sidebar-offcanvas').addClass('sticky'); 			
				}
			} else {  
			    $('#content-wrapper, .search-sidebar-offcanvas').removeClass('sticky');  			     
			}  
		};
		if ($('#fixed-header').length) {
		    fixedHeader();
		}
		
	}
	
	
	
	// Controlling the height of the content elements to fill screen regardless of content	
	//$('#content-outer-wrapper').css('min-height', contentHeight);
	//$('#content-wrapper').css('min-height', contentHeight);
	
	
    //console.log('Window =' + windowHeight + '\n' + ' Header =' + headerHeight + '\n' + ' Sidebar =' + sidebarHeight + '\n');
  };

  return {
    size: size
  };
});