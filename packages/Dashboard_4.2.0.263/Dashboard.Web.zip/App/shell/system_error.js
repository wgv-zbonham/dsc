define(["require", "exports"], function (require, exports) {
    var systemError = (function () {
        function systemError() {
        }
        systemError.prototype.attached = function () {
            console.error('system error attached');
            $('#header').css({ display: 'none' });
            $('#load-wait').css({ display: 'none' });
            $('#applicationHost').css({ display: 'inline' });
            $('body').addClass('error');
            var title = $('title').text();
            var code = 500;
            if (title.indexOf('|') > -1) {
                title = title.split('|')[0];
            }
            if (title.toLowerCase().indexOf('error') > -1) {
                code = 500;
            }
            else if (title.toLowerCase().indexOf('page') > -1) {
                code = 404;
            }
            else if (title.toLowerCase().indexOf('authorized') > -1) {
                code = 403;
            }
            $('#error-code').text(code);
            $('#error-title').text(title);
        };
        systemError.prototype.deactivate = function () {
            $('#header').css({ display: 'block' });
        };
        return systemError;
    })();
    return systemError;
});
//# sourceMappingURL=system_error.js.map