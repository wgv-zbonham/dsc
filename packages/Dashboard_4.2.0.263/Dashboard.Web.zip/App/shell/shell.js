﻿define([
        'plugins/router', 'durandal/app', 'durandal/system', 'uiServices/windowSizer', 'uiServices/documentFoundation',
        'models/viewTransitionStateBag', 'dashboard/services/dashboardService', 'dashboard/models/applicationPaths'
        //'services/errorhandler'
],
      function (router, app, system, sizer, docFoundation,
                viewTransition, dashboardService, departmentInfo) {

          var timerId;

          var buildNumber = ko.observable(0);
          var versionNumber = ko.observable(0);
          var userName = ko.observable('');
          var exportCount = ko.observable('');
          var myExportCount = ko.observable(0);
          var dropDownRoutes = ko.observable();
          var departmentName = ko.observable('');
          var reportsPath = ko.observable('');
          var elWebPath = ko.observable('');

          var boot = function() {
              var deferred = $.Deferred();

              // This is needed to mitigate issues between Foundation, KnockoutJS, and possibly qTip; essentially, in certain circumstances, these look for attributes on comments in the view markup...not good.
              Object.getPrototypeOf(document.createComment('')).getAttribute = function() {};

              $(document).ajaxComplete(function(e, xhr, settings) {
                  if (xhr.status && xhr.status === 304) {
                      console.error('status: ' + xhr.status + ' for url ' + settings.url);
                  }
              });

              dashboardService.dashboardService.getApplicationPaths().then(function(data) {
                  departmentInfo.setElWebPath(data.elWebPath);
                  departmentInfo.setDashboardPath(data.dashboardPath);
                  departmentInfo.setReportsPath(data.reportsPath);
                  reportsPath(data.reportsPath);
                  elWebPath(data.elWebPath);

                  dashboardService.dashboardService.getDepartmentInfo().then(function (data) {
                      departmentName(data.name);
                      userName(data.username);
                      buildNumber(data.buildNumber);
                      versionNumber(data.versionNumber);
                  });
              });

                var routesMap = router.map([
                    { route: '', title: 'Dashboard', moduleId: 'dashboard/dashboard/dashboard' },
                    { route: 'dashboard/officerEvents', title: 'Officer Details', moduleId: 'dashboard/officerEvents/officerEvents' },
                    { route: 'dashboard/eventCategory', title: 'Event Category', moduleId: 'dashboard/eventCategory/eventCategory' },
                    { route: 'pageNotFound', 'title': 'Page Not Found', moduleId: 'shell/system_error' },
                    //{ route: 'notAuthorized', title: 'Not Authorized', moduleId: 'shell/system_error' },
                    //{ route: 'error', title: 'Error Page', moduleId: 'shell/system_error' }
                ]);

                routesMap.buildNavigationModel()
                    .mapUnknownRoutes(function(routeConfig, replaceRoute) {
                        //   toastr.info('No Route Found: ' + routeConfig.route);
                        router.navigate('#pageNotFound');
                    });


                ko.validation.init({ insertMessages: false, errorElementClass: 'error', decorateElement: true, decorateInputElement: true });

                return router.activate()
                    .done(function() {
                        deferred.resolve();
                    });
          };

          return {
              buildNumber: buildNumber,
              versionNumber: versionNumber,
              router: router,
              userName: userName,
              reportsPath: reportsPath,
              elWebPath: elWebPath,
              exportCount: exportCount,
              myExportCount: myExportCount,
              dropDownRoutes: dropDownRoutes,
              departmentName: departmentName,
              attached: function () {
                  system.log('shell attached');

                  viewTransition.stateBag.isShellComposed = false;
                  docFoundation.init();

                  timerId = window.setTimeout(function () {
                      console.error('shell composition failed. navigating to system error page');
                      router.navigate('error');
                  }, 30000);
              },

              compositionComplete: function () {
                  system.log('shell composition complete');

                  window.clearTimeout(timerId);
                  $(window).resize(sizer.size);
                  $(window).scroll(sizer.size);

                  $('#load-wait').css({ display: 'none' });
                  $('#applicationHost').css({ display: 'block' });

                  viewTransition.stateBag.isShellComposed = true;


                  // tip styling and config
                  // init tooltips and positioning classes
                  $(document).on('mouseenter', '[data-tooltip], .has-tip', function (event) {

                      var posMy = 'top center',
                          posAt = 'bottom center';


                      if ($(this).hasClass('tip-top')) {
                          posMy = 'bottom center';
                          posAt = 'top center';
                      }
                      if ($(this).hasClass('tip-right')) {
                          posMy = 'left center';
                          posAt = 'right center';
                      }
                      if ($(this).hasClass('tip-bottom')) {
                          posMy = 'top center';
                          posAt = 'bottom center';
                      }
                      if ($(this).hasClass('tip-left')) {
                          posMy = 'right center';
                          posAt = 'left center';
                      }

                      if ($(this).hasClass('tip-top-right')) {
                          posMy = 'bottom left';
                          posAt = 'top right';
                      }
                      if ($(this).hasClass('tip-bottom-right')) {
                          posMy = 'top left';
                          posAt = 'right bottom';
                      }
                      if ($(this).hasClass('tip-top-left')) {
                          posMy = 'right bottom';
                          posAt = 'top left';
                      }
                      if ($(this).hasClass('tip-bottom-left')) {
                          posMy = 'right top';
                          posAt = 'left bottom';
                      }


                      $(this).qtip({
                          //style: { classes: 'wgv-tooltip' },
                          overwrite: false, // Don't overwrite tooltips already bound
                          show: {
                              event: event.type, // Use the same show event as the one that triggered the event handler
                              ready: true,
                              // Show the tooltip as soon as it's bound, vital so it shows up the first time you hover!,
                              solo: true
                          },
                          hide: {
                              when: { event: 'click mouseleave' },
                              effect: { type: 'slide' }
                          },
                          position: {
                              my: posMy,
                              at: posAt,
                              target: $(this), // my target
                              container: $('body'),
                              viewport: true,
                              adjust: {
                                  method: 'flip',
                                  resize: true,
                                  scroll: true // Can be ommited (e.g. default behaviour)  // Position my top left...
                              },

                          }
                      }, event); // Pass through our original event to qTip
                  });

                  $(document).on('click', '[data-tooltip]', function (event) {
                      $(".qtip").hide();
                  });

              }, // composition complete

              activate: function () {
                  return boot();
              }
          };
      });
