(function () {

    requirejs.config({
        //urlArgs: 'elwebversion=' + elWebVersion,

        //NEED TO SWAP TO ./DASHBOARD/APP WHEN DEPLOYING
        //baseUrl: './Dashboard/App',
        baseUrl: './App',
        paths: {
            text: '../Scripts/text',
            durandal: '../Scripts/durandal',
            plugins: '../Scripts/durandal/plugins',
            transitions: '../Scripts/durandal/transitions',
            foundation: '../Scripts/foundation',
            filesize: '../Scripts/filesize',
            pluralize: '../Scripts/pluralize',
            'qtip': '../Scripts/jquery.qtip',
            highcharts: '../Scripts/highStock',
            moment: '../Scripts/moment',
            googlemaps: '../Scripts/require/googlemaps',
            async: '../Scripts/require/async',
            chosen: '../Scripts/chosen.jquery',
            markerClusterer: '../Scripts/markerclusterer',
            chosenOrder: '../Scripts/chosen-order'
        },
        googlemaps: {
            params: {
                key: 'AIzaSyCu9Dc18r5kno73g56aiT5xfOQzWW3UWiU',
                libraries: 'visualization',
                v: 3
            }
        },
        shim: {
            'markerclusterer': {
                exports: "MarkerClusterer"
            },
            'chosenOrder': {
                exports: "ChosenOrder"
            }
        }
    });

    define('jquery', function () { return jQuery; });
    define('knockout', function () { return ko; });
    define('chosen', function () { return chosen; });
    define('markerClusterer', function () { return MarkerClusterer; });
    define('chosenOrder', function () { return ChosenOrder; }); //for multiselect support
    
    //define('googlemaps!', function(gmaps) {
    //    return gmaps;
    //});


})();

//todo: remove having to pass chosenOrder here. I should be able to do it in filterControl but can't get it to work
require(['durandal/system', 'durandal/app', 'durandal/viewLocator', 'dialogConfiguration', 'chosenOrder'], function (system, app, viewLocator, dialogConfiguration, chosenOrder) {

    system.debug(window.dashboard.config.enableDebugMode);

    app.title = 'Evidence Library';

    app.configurePlugins({
        router: true,
        observable: true,
        dialog: true,
        widget: false,
        history: true
    });

    dialogConfiguration.configure();

    app.start().then(function () {
        //Replace 'viewmodels' in the moduleId with 'views' to locate the view.
        //Look for partial views in a 'views' folder in the root.
        viewLocator.useConvention();
        viewLocator.translateViewIdToArea = function (viewId, area) {
            return viewId;
        };

        //Show the app by setting the root view model for our application with a transition.
        app.setRoot('shell/shell', 'entrance');
    });
});