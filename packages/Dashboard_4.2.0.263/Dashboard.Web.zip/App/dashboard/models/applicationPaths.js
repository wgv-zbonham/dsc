define(["require", "exports"], function (require, exports) {
    var vm = {
        elWebPath: '',
        dashboardPath: '',
        reportsPath: '',
        getElWebPath: function () {
            return vm.elWebPath;
        },
        setElWebPath: function (path) {
            vm.elWebPath = path;
            localStorage.setItem('applicationPaths', JSON.stringify(vm));
        },
        getDashboardPath: function () {
            return vm.dashboardPath;
        },
        setDashboardPath: function (path) {
            vm.dashboardPath = path;
            localStorage.setItem('applicationPaths', JSON.stringify(vm));
        },
        getReportsPath: function () {
            return vm.reportsPath;
        },
        setReportsPath: function (path) {
            vm.reportsPath = path;
            localStorage.setItem('applicationPaths', JSON.stringify(vm));
        },
        init: function () {
            if (!localStorage.getItem('applicationPaths')) {
                localStorage.setItem('departmentInfo', JSON.stringify(vm));
                console.log('unable to retrieve applicationPaths from localstorage.');
            }
            else {
                var departmentInfo = JSON.parse(localStorage.getItem('applicationPaths'));
                vm.elWebPath = departmentInfo.elWebPath;
                vm.dashboardPath = departmentInfo.dashboardPath;
                vm.reportsPath = departmentInfo.reportsPath;
            }
        }
    };
    vm.init();
    return vm;
});
//# sourceMappingURL=applicationPaths.js.map