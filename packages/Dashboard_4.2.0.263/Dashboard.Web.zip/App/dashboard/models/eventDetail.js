//import Officer = require("dashboard/models/officer");
//interface EventDetail {
//    category: string;
//    officer: Officer;
//    date: Date;
//    time: string;
//    deviceId: string;
//    coordinates: string;
//    duration: number;
//    size: number;
//    shared: number;
//}
//export = EventDetail; 
//# sourceMappingURL=eventDetail.js.map