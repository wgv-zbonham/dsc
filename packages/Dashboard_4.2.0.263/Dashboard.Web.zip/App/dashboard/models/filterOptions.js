define(["require", "exports", "dashboard/models/timeFrame"], function (require, exports, TimeFrame) {
    var vm = {
        selectedOfficers: [],
        selectedCategories: [],
        availableOfficers: [],
        selectedTimeFrame: TimeFrame.ThirtyDays,
        getOfficers: function () {
            return vm.selectedOfficers;
        },
        setOfficers: function (officers) {
            vm.selectedOfficers = officers;
            localStorage.setItem('filterOptions', JSON.stringify(vm));
        },
        getCategories: function () {
            return vm.selectedCategories;
        },
        setCategories: function (categories) {
            vm.selectedCategories = categories;
            localStorage.setItem('filterOptions', JSON.stringify(vm));
        },
        getAvailableOfficers: function () {
            return vm.availableOfficers;
        },
        setAvailableOfficers: function (officers) {
            vm.availableOfficers = officers;
            localStorage.setItem('filterOptions', JSON.stringify(vm));
        },
        getTimeFrame: function () {
            return vm.selectedTimeFrame;
        },
        setTimeFrame: function (timeFrame) {
            vm.selectedTimeFrame = timeFrame;
            localStorage.setItem('filterOptions', JSON.stringify(vm));
        },
        init: function () {
            if (!localStorage.getItem('filterOptions')) {
                localStorage.setItem('filterOptions', JSON.stringify(vm));
                console.log('unable to retrieve filterOptions from localstorage. Creating default controls...');
            }
            else {
                var filterOptions = JSON.parse(localStorage.getItem('filterOptions'));
                vm.selectedOfficers = filterOptions.selectedOfficers;
                vm.selectedCategories = filterOptions.selectedCategories;
                vm.selectedTimeFrame = filterOptions.selectedTimeFrame;
                vm.availableOfficers = filterOptions.availableOfficers;
            }
        }
    };
    vm.init();
    return vm;
});
//# sourceMappingURL=filterOptions.js.map