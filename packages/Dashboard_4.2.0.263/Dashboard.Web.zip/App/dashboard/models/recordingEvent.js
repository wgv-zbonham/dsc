define(["require", "exports"], function (require, exports) {
    var RecordingEvent = (function () {
        function RecordingEvent() {
        }
        return RecordingEvent;
    })();
    return RecordingEvent;
});
//# sourceMappingURL=recordingEvent.js.map