define(["require", "exports"], function (require, exports) {
    var Officer = (function () {
        function Officer(officer) {
            var _this = this;
            this.getFullName = function () {
                return _this.firstName + " " + _this.lastName;
            };
            this.map = function (officer) {
                if (officer) {
                    officer.id = _this.id;
                    officer.firstName = _this.firstName;
                    officer.lastName = _this.lastName;
                    officer.eventCategories = _this.eventCategories;
                    officer.shortFullName = _this.getAbreviatedFullName();
                    officer.longFullName = _this.getLongFullName();
                }
            };
            this.getAbreviatedFullName = function () {
                return _this.firstName ? _this.lastName + ", " + _this.firstName.substr(0, 1) : _this.lastName;
            };
            this.getLongFullName = function () {
                if (_this.firstName && _this.lastName) {
                    return _this.lastName + ", " + _this.firstName;
                }
                else if (_this.lastName) {
                    return _this.lastName + ", ";
                }
                else if (_this.firstName) {
                    return ", " + _this.firstName;
                }
                else {
                    return "Unknown";
                }
            };
            this.setProperties = function (officer) {
                if (officer) {
                    _this.id = officer.id;
                    _this.firstName = officer.firstName;
                    _this.lastName = officer.lastName;
                    _this.eventCategories = officer.eventCategories;
                    _this.shortFullName = _this.getAbreviatedFullName();
                    _this.longFullName = _this.getLongFullName();
                }
            };
            this.setProperties(officer);
        }
        return Officer;
    })();
    return Officer;
});
//# sourceMappingURL=officer.js.map