define(["require", "exports", "dashboard/models/activityTypeSummaries"], function (require, exports, ActivityTypeSummaries) {
    var Statistician = (function () {
        function Statistician() {
            var _this = this;
            this.getOrderedActivityTypesByOfficer = function (result, officerIds) {
                return _this.getOrderedActivitySummaries(result, officerIds);
            };
            this.getOrderedActivityTypesByCategory = function (result, categoryIds) {
                return _this.getOrderedActivitySummaries(result, categoryIds);
            };
            this.getOrderedActivitySummaries = function (result, ids) {
                var orderedSummaries = new ActivityTypeSummaries();
                //var selectedOfficerIds = FilterOptions.getOfficers(); //uses ordered officerIds
                if (ids.length > 0) {
                    _.each(ids, function (id) {
                        _this.addOrderedSummaries(result.uploaded, orderedSummaries.uploaded, id);
                        _this.addOrderedSummaries(result.archivedPurged, orderedSummaries.archivedPurged, id);
                        _this.addOrderedSummaries(result.exported, orderedSummaries.exported, id);
                        _this.addOrderedSummaries(result.played, orderedSummaries.played, id);
                    });
                    return orderedSummaries;
                }
                else {
                    return result;
                }
            };
        }
        Statistician.prototype.addOrderedSummaries = function (fromArray, toArray, officerId) {
            var foundUpload = _.findWhere(fromArray, { id: officerId });
            foundUpload ? toArray.push(foundUpload) : toArray.push({ id: officerId, count: 0 });
        };
        return Statistician;
    })();
    exports.statistician = new Statistician;
});
//# sourceMappingURL=statistician.js.map