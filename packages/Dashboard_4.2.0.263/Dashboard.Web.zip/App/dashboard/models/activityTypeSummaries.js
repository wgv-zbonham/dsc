define(["require", "exports"], function (require, exports) {
    var ActivityTypeSummaries = (function () {
        function ActivityTypeSummaries(stats) {
            var _this = this;
            this.getExportedTotal = function () {
                var total = 0;
                _.each(_this.exported, function (ex) {
                    total = total + ex.count;
                });
                return total;
            };
            if (stats) {
                this.uploaded = stats.uploaded;
                this.played = stats.played;
                this.exported = stats.exported;
                this.archivedPurged = stats.archivedPurged;
            }
            else {
                this.uploaded = [];
                this.played = [];
                this.exported = [];
                this.archivedPurged = [];
            }
        }
        ActivityTypeSummaries.prototype.getUploadedTotal = function () {
            var total = 0;
            _.each(this.uploaded, function (upload) {
                total = total + upload.count;
            });
            return total;
        };
        ActivityTypeSummaries.prototype.getPlayedTotal = function () {
            var total = 0;
            _.each(this.played, function (play) {
                total = total + play.count;
            });
            return total;
        };
        ActivityTypeSummaries.prototype.getArchivedPurgedTotal = function () {
            var total = 0;
            _.each(this.archivedPurged, function (archivePurge) {
                total = total + archivePurge.count;
            });
            return total;
        };
        return ActivityTypeSummaries;
    })();
    return ActivityTypeSummaries;
});
//# sourceMappingURL=activityTypeSummaries.js.map