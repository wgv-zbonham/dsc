define(["require", "exports"], function (require, exports) {
    var EventCategory = (function () {
        function EventCategory() {
        }
        return EventCategory;
    })();
    return EventCategory;
});
//# sourceMappingURL=eventCategory.js.map