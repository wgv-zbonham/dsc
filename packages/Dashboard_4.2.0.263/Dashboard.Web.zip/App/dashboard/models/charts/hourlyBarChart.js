define(["require", "exports"], function (require, exports) {
    var HourlyBarChart = (function () {
        function HourlyBarChart(domId) {
            var _this = this;
            this.redraw = function (seriesData) {
                _this.chart.series[0].setData(seriesData[0].data);
                _.each(seriesData, function (element, i) {
                    _this.chart.series[i].setData(seriesData[i].data);
                });
            };
            this.addSeries = function (seriesData) {
                //this adds 1 at a time. If I want to add n items, loop and add
                _this.chart.addSeries(seriesData, false);
                _this.chart.redraw();
            };
            this.removeSeries = function (officerIndex) {
                //remove last element in series
                if (_this.chart.series.length > 1) {
                    _this.chart.series[officerIndex].remove();
                }
            };
            this.buildChart = function (seriesData) {
                //'#hourlyGraph'
                $(_this.domId).highcharts({
                    chart: {
                        type: 'column',
                        marginTop: 60
                    },
                    title: {
                        text: ''
                    },
                    legend: {
                        enabled: false
                    },
                    xAxis: {
                        categories: ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23']
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: ''
                        }
                    },
                    tooltip: {
                        pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
                        shared: true
                    },
                    plotOptions: {
                        column: {
                            stacking: 'normal',
                            borderWidth: 0,
                            pointWidth: 8
                        },
                    },
                    series: seriesData
                });
                _this.chart = $(_this.domId).highcharts();
            };
            this.getRandomHourlySeriesData = function () {
                var series = [];
                for (var i = 0; i < 24; i++) {
                    var randNum = Math.floor((Math.random() * 100) + 1); //random # between 1 and 100
                    series.push(randNum);
                }
                return series;
            };
            this.domId = domId;
        }
        return HourlyBarChart;
    })();
    return HourlyBarChart;
});
//# sourceMappingURL=hourlyBarChart.js.map