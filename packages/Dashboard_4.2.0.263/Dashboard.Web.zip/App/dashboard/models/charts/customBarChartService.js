define(["require", "exports"], function (require, exports) {
    var CustomBarChartService = (function () {
        function CustomBarChartService() {
            var _this = this;
            this.getCustomCategoryBarChartData = function (officers, categories, showZeroValues) {
                if (showZeroValues === void 0) { showZeroValues = true; }
                if (!showZeroValues) {
                    categories = _this.excludeCategoriesWithZeroValues(categories, officers);
                }
                var categoryChartEntries = [];
                if (!categories || categories.length <= 0) {
                    return categoryChartEntries;
                }
                var categoryTotals = [];
                _.each(officers, function (officer) {
                    if (officer) {
                        _.each(categories, function (category, index) {
                            //find from officer's categories, where category is selected cat
                            var categorySummary = _.findWhere(officer.eventCategories, { id: category.id });
                            if (categoryTotals[index] === null || categoryTotals[index] === undefined) {
                                //first time through
                                categoryTotals.push({ category: categorySummary, total: categorySummary.count });
                            }
                            else {
                                categoryTotals[index].total = categoryTotals[index].total + categorySummary.count;
                            }
                        });
                    }
                });
                var sortedCategoryTotals = _this.sortCategories(categoryTotals);
                var maxTotal = sortedCategoryTotals[0].total;
                _.each(sortedCategoryTotals, function (categoryTotal) {
                    var barChartEntry = [];
                    var entryTotal = 0;
                    _.each(officers, function (officer) {
                        if (officer) {
                            var categoryEntry = _.findWhere(officer.eventCategories, { id: categoryTotal.category.id });
                            entryTotal = entryTotal + categoryEntry.count;
                            var width = (categoryEntry.count / maxTotal) * 100;
                            width = parseInt(width.toString());
                            var percentWidth = width.toString() + '%';
                            var title = officer.shortFullName + ": " + categoryEntry.count;
                            barChartEntry.push({ width: percentWidth, title: title });
                        }
                    });
                    categoryChartEntries.push({ id: categoryTotal.category.id, label: categoryTotal.category.name, barChartData: barChartEntry, total: entryTotal });
                });
                return categoryChartEntries;
            };
            this.getCustomOfficersBarChartData = function (selectedOfficers, selectedCategories) {
                var officerChartEntries = [];
                if (!selectedOfficers || selectedOfficers.length <= 0) {
                    return officerChartEntries;
                }
                var officerTotals = [];
                _.each(selectedOfficers, function (officer) {
                    var total = 0;
                    _.each(selectedCategories, function (category) {
                        //find from officer's categories, where category is selected cat
                        var categorySummary = _.findWhere(officer.eventCategories, { id: category.id });
                        total = total + categorySummary.count;
                    });
                    officerTotals.push({ officer: officer, categories: officer.eventCategories, total: total });
                });
                var sortedOfficerTotals = _this.sortOfficers(officerTotals);
                if (sortedOfficerTotals && sortedOfficerTotals.length > 0) {
                    var maxTotal = sortedOfficerTotals[0].total;
                    _.each(sortedOfficerTotals, function (officerTotal) {
                        var barChartEntry = [];
                        var entryTotal = 0;
                        _.each(selectedCategories, function (category) {
                            //find from officer's categories, where category is selected cat
                            var categorySummary = _.findWhere(officerTotal.categories, { id: category.id });
                            entryTotal = entryTotal + categorySummary.count;
                            var width = (categorySummary.count / maxTotal) * 100;
                            width = parseInt(width.toString());
                            var percentWidth = width.toString() + '%';
                            var title = category.name + ": " + categorySummary.count;
                            barChartEntry.push({ width: percentWidth, title: title });
                        });
                        officerChartEntries.push({ id: officerTotal.officer.id, label: officerTotal.officer.shortFullName, barChartData: barChartEntry, total: entryTotal });
                    });
                }
                return officerChartEntries;
            };
            this.getCustomOfficersBarChartSummarizedData = function (selectedOfficers, selectedCategories) {
                var officerChartEntries = [];
                if (!selectedOfficers || selectedOfficers.length <= 0) {
                    return officerChartEntries;
                }
                var officerTotals = [];
                _.each(selectedOfficers, function (officer) {
                    var total = 0;
                    _.each(selectedCategories, function (category) {
                        //find from officer's categories, where category is selected cat
                        var categorySummary = _.findWhere(officer.eventCategories, { id: category.id });
                        total = total + categorySummary.count;
                    });
                    officerTotals.push({ officer: officer, categories: officer.eventCategories, total: total });
                });
                var sortedOfficerTotals = _this.sortOfficers(officerTotals);
                var maxTotal = sortedOfficerTotals[0].total;
                _.each(sortedOfficerTotals, function (officerTotal) {
                    //todo: move duplicated code to reusable method once finishing out functionality for all//////////////////////////////
                    var barChartEntry = [];
                    var entryTotal = 0;
                    entryTotal = entryTotal + officerTotal.total;
                    var width = (officerTotal.total / maxTotal) * 100;
                    width = parseInt(width.toString());
                    var percentWidth = width.toString() + '%';
                    var title = "All Categories: " + officerTotal.total;
                    barChartEntry.push({ width: percentWidth, title: title });
                    officerChartEntries.push({ id: officerTotal.officer.id, label: officerTotal.officer.shortFullName, barChartData: barChartEntry, total: entryTotal });
                    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                });
                return officerChartEntries;
            };
            this.excludeCategoriesWithZeroValues = function (categories, officers) {
                var categoriesToInlcue = [];
                _.each(officers, function (officer) {
                    if (officer) {
                        _.each(officer.eventCategories, function (category) {
                            if (category.count > 0) {
                                categoriesToInlcue.push(category.id);
                            }
                        });
                    }
                });
                var allCategories = _.pluck(categories, 'id');
                var idsToInclude = _.intersection(allCategories, categoriesToInlcue);
                categories = _.filter(categories, function (category) {
                    return _.contains(idsToInclude, category.id);
                });
                return categories;
            };
            this.sortOfficers = function (officerTotals) {
                //http://stackoverflow.com/questions/16907554/sort-the-contained-objects-in-an-array-by-the-last-name-first-name-descending
                officerTotals.sort(function (a, b) { return (b.total - a.total ||
                    a.officer.lastName.localeCompare(b.officer.lastName) ||
                    b.officer.firstName.localeCompare(a.officer.firstName) || 0); });
                return officerTotals;
            };
            this.sortCategories = function (categoryTotals) {
                //http://stackoverflow.com/questions/16907554/sort-the-contained-objects-in-an-array-by-the-last-name-first-name-descending
                categoryTotals.sort(function (a, b) { return (b.total - a.total ||
                    a.category.name.localeCompare(b.category.name) || 0); });
                return categoryTotals;
            };
        }
        return CustomBarChartService;
    })();
    exports.customBarChartService = new CustomBarChartService();
});
//# sourceMappingURL=customBarChartService.js.map