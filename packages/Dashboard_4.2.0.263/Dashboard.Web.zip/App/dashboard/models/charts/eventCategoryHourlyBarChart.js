var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "dashboard/models/charts/hourlyBarChart"], function (require, exports, HourlyBarChart) {
    var EventCategoryHourlyBarChart = (function (_super) {
        __extends(EventCategoryHourlyBarChart, _super);
        function EventCategoryHourlyBarChart(summaries, domId) {
            var _this = this;
            _super.call(this, domId);
            this.build = function (hourlyStats) {
                _this.buildChart(_this.getHourlySeries(hourlyStats));
            };
            this.updateSeriesData = function (hourlyStats) {
                _this.redraw(_this.getHourlySeries(hourlyStats));
            };
            this.addToChart = function (eventCategorySummary) {
                var seriesData = {
                    name: eventCategorySummary.name,
                    data: _this.getRandomHourlySeriesData()
                };
                _this.addSeries(seriesData);
            };
            this.getHourlySeries = function (hourlyStats) {
                var seriesData = [];
                _.each(hourlyStats, function (entry) {
                    var entries = [];
                    _.each(entry.hourEntries, function (hourEntry) {
                        entries.push(hourEntry);
                    });
                    seriesData.push({
                        name: entry.categorySummary.name,
                        data: entries
                    });
                });
                return seriesData;
            };
            this.eventCategorySummaries = summaries;
        }
        return EventCategoryHourlyBarChart;
    })(HourlyBarChart);
    return EventCategoryHourlyBarChart;
});
//# sourceMappingURL=eventCategoryHourlyBarChart.js.map