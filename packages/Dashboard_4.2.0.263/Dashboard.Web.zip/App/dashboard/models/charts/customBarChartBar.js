define(["require", "exports"], function (require, exports) {
});
//# sourceMappingURL=customBarChartBar.js.map