var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "dashboard/models/timeFrame", "dashboard/models/charts/dailyLineChart"], function (require, exports, TimeFrame, DailyLineChart) {
    var EventCategoryDailyLineChart = (function (_super) {
        __extends(EventCategoryDailyLineChart, _super);
        function EventCategoryDailyLineChart(eventCategorySummaries, domId) {
            var _this = this;
            _super.call(this, domId);
            this.build = function (dailyStats, timeFrame) {
                var seriesData = (timeFrame === TimeFrame.TwelveMonths) ? _this.getAggregateSeries(dailyStats) : _this.getDailySeries(dailyStats);
                timeFrame === TimeFrame.TwelveMonths ? _this.buildMonthlyAggregateChart(seriesData) : _this.buildChart(seriesData);
            };
            this.getDailySeries = function (dailyStats) {
                var seriesData = [];
                _.each(dailyStats, function (entry) {
                    var entries = [];
                    _.each(entry.dayEntries, function (dayEntry) {
                        var date = moment(dayEntry.date);
                        var d = Date.UTC(date.year(), date.month(), date.date());
                        entries.push([d, dayEntry.count]);
                    });
                    seriesData.push({
                        name: entry.categorySummary.name,
                        data: entries
                    });
                });
                return seriesData;
            };
            this.getAggregateSeries = function (dailyStats) {
                var seriesData = [];
                _.each(dailyStats, function (entry) {
                    var entries = [];
                    entry.dayEntries = entry.dayEntries.reverse();
                    _.each(entry.dayEntries, function (dayEntry) {
                        entries.push(dayEntry.count);
                    });
                    seriesData.push({
                        name: entry.categorySummary.name,
                        data: entries
                    });
                });
                var monthNames = [];
                if (dailyStats.length > 0) {
                    _.each(dailyStats[0].dayEntries, function (dayEntry) {
                        monthNames.push(moment(dayEntry.date).format("MMM 'YY"));
                    });
                }
                return { seriesData: seriesData, months: monthNames };
            };
            this.eventCategorySummaries = eventCategorySummaries;
        }
        return EventCategoryDailyLineChart;
    })(DailyLineChart);
    return EventCategoryDailyLineChart;
});
//# sourceMappingURL=eventCategoryDailyLineChart.js.map