define(["require", "exports", 'durandal/app', "dashboard/models/constants", "dashboard/models/filterOptions", "dashboard/services/dashboardService", "markerClusterer"], function (require, exports, app, constants, FilterOptions, DashboardService) {
    /// <reference path="../../../../scripts/typings/googlemaps/google.maps.d.ts" />
    /// <amd-dependency path="markerClusterer"/>
    var MarkerClusterer = require('markerClusterer');
    var gmaps;
    require(['googlemaps!'], function (googlemaps) {
        gmaps = googlemaps;
    }, function (error) {
        app.trigger(constants.DASHBOARD_MAP_FAILED_TO_LOAD);
    });
    var EventMap = (function () {
        function EventMap(events, isShowingAllCategories) {
            var _this = this;
            this.markers = [];
            this.showMarkersCallbackCount = 0;
            this.build = function () {
                _this.getMapZoomPosition().then(function () {
                    _this.zoomMapAndInit();
                }).fail(function () {
                    console.log('Unable to retrieve SearchLocality from DepartmentConfiguration table. Setting default to Allen TX.');
                    //if we fail to get their coordinates, we will set it to Allen TX. This should let us know that we need to set this value in db.
                    _this.mapZoomCoordinates = new gmaps.LatLng(33.1128019, -96.6958939);
                    _this.zoomMapAndInit();
                });
            };
            this.addMarkers = function (events) {
                _this.events = events;
                //clear out all markers first
                _.each(_this.markers, function (marker) {
                    marker.setMap(null);
                });
                var orderedAndGroupedEventsByCategory = _this.getGroupedAndOrderedEventsByCategory(_this.events);
                var count = 0; //need to use count here b/c we can't rely on the index of groupedEventsByCatgory as it is not an array
                _.each(orderedAndGroupedEventsByCategory, function (groupedEvents) {
                    var image;
                    if (!_this.isShowingAllCategories) {
                        image = 'Assets/Images/mcat' + (Math.min(count + 1, 3)) + '.png'; // Max number of category images is 3
                    }
                    else {
                        image = 'Assets/Images/mcat1.png';
                    }
                    _.each(groupedEvents, function (event) {
                        var marker = new gmaps.Marker({
                            position: new gmaps.LatLng(event.latitude, event.longitude),
                            map: _this.map,
                            icon: image
                        });
                        var contentString = '<div id="content">' +
                            '<h1 id="firstHeading" class="firstHeading">' + event.eventCategory.name + '</h1>' +
                            '<div id="bodyContent">' +
                            '<div>' + moment.utc(event.recordingStartDate).local().format('MMM D, YYYY HH:mm') + '</div>' +
                            '<p>' + event.officer.shortFullName + '</p>' +
                            '</div>' +
                            '</div>';
                        var infowindow = new gmaps.InfoWindow({
                            content: contentString
                        });
                        marker.addListener('click', function () {
                            infowindow.open(_this.map, marker);
                        });
                        _this.markers.push(marker);
                    });
                    count = count + 1;
                });
            };
            this.zoomMapAndInit = function () {
                _this.map = new gmaps.Map(document.getElementById('dash-map'), {
                    zoom: 12,
                    center: _this.mapZoomCoordinates,
                    mapTypeControlOptions: {
                        mapTypeId: gmaps.MapTypeId.ROADMAP,
                        position: gmaps.ControlPosition.TOP_RIGHT
                    }
                });
                gmaps.event.addListener(_this.map, 'idle', _this.showMarkers);
                //todo: uncomment for testing heatmaps
                //var heatmap = new gmaps.visualization.HeatmapLayer({
                //    data: this.getPointsForHeatMap(events),
                //    map: map,
                //    radius: 20,
                //    opacity: 1
                //});
                _this.addMarkers(_this.events);
                //if (events.length > 1000) {
                //var markerCluster = new MarkerClusterer(this.map, markers, { imagePath: './Assets/Images/m', minimumClusterSize: 40, zoomOnClick: true, maxZoom: 18 });
                //}
                _this.map.set('styles', [
                    {
                        "featureType": "administrative",
                        "elementType": "labels.text.fill",
                        "stylers": [
                            {
                                "color": "#ffffff"
                            }
                        ]
                    },
                    {
                        "featureType": "administrative",
                        "elementType": "labels.text.stroke",
                        "stylers": [
                            {
                                "hue": "#0062ff"
                            },
                            {
                                "saturation": "10"
                            },
                            {
                                "lightness": "-25"
                            },
                            {
                                "gamma": "1.00"
                            },
                            {
                                "weight": "2.31"
                            },
                            {
                                "visibility": "on"
                            }
                        ]
                    },
                    {
                        "featureType": "landscape",
                        "elementType": "all",
                        "stylers": [
                            {
                                "color": "#f2f2f2"
                            }
                        ]
                    },
                    {
                        "featureType": "landscape",
                        "elementType": "geometry.fill",
                        "stylers": [
                            {
                                "visibility": "on"
                            },
                            {
                                "lightness": "-25"
                            },
                            {
                                "saturation": "10"
                            },
                            {
                                "hue": "#0062ff"
                            }
                        ]
                    },
                    {
                        "featureType": "poi",
                        "elementType": "all",
                        "stylers": [
                            {
                                "visibility": "off"
                            }
                        ]
                    },
                    {
                        "featureType": "poi.park",
                        "elementType": "geometry.fill",
                        "stylers": [
                            {
                                "hue": "#00ff5e"
                            },
                            {
                                "visibility": "on"
                            },
                            {
                                "saturation": "-81"
                            },
                            {
                                "lightness": "-18"
                            }
                        ]
                    },
                    {
                        "featureType": "road",
                        "elementType": "all",
                        "stylers": [
                            {
                                "saturation": -100
                            },
                            {
                                "lightness": 45
                            }
                        ]
                    },
                    {
                        "featureType": "road",
                        "elementType": "geometry.fill",
                        "stylers": [
                            {
                                "hue": "#0062ff"
                            },
                            {
                                "saturation": "10"
                            },
                            {
                                "lightness": "-37"
                            },
                            {
                                "gamma": "1.00"
                            }
                        ]
                    },
                    {
                        "featureType": "road",
                        "elementType": "geometry.stroke",
                        "stylers": [
                            {
                                "weight": "0.01"
                            }
                        ]
                    },
                    {
                        "featureType": "road",
                        "elementType": "labels.text.fill",
                        "stylers": [
                            {
                                "lightness": "-88"
                            },
                            {
                                "hue": "#0062ff"
                            }
                        ]
                    },
                    {
                        "featureType": "road",
                        "elementType": "labels.text.stroke",
                        "stylers": [
                            {
                                "hue": "#0062ff"
                            },
                            {
                                "saturation": "10"
                            },
                            {
                                "lightness": "-25"
                            },
                            {
                                "visibility": "on"
                            },
                            {
                                "weight": "2.03"
                            }
                        ]
                    },
                    {
                        "featureType": "road",
                        "elementType": "labels.icon",
                        "stylers": [
                            {
                                "hue": "#0062ff"
                            },
                            {
                                "saturation": "10"
                            },
                            {
                                "lightness": "1"
                            },
                            {
                                "gamma": "1.00"
                            },
                            {
                                "visibility": "simplified"
                            }
                        ]
                    },
                    {
                        "featureType": "road.highway",
                        "elementType": "all",
                        "stylers": [
                            {
                                "visibility": "simplified"
                            }
                        ]
                    },
                    {
                        "featureType": "road.highway",
                        "elementType": "geometry.fill",
                        "stylers": [
                            {
                                "visibility": "on"
                            },
                            {
                                "lightness": "18"
                            }
                        ]
                    },
                    {
                        "featureType": "road.highway.controlled_access",
                        "elementType": "labels.text.fill",
                        "stylers": [
                            {
                                "visibility": "on"
                            }
                        ]
                    },
                    {
                        "featureType": "road.highway.controlled_access",
                        "elementType": "labels.text.stroke",
                        "stylers": [
                            {
                                "visibility": "on"
                            },
                            {
                                "weight": "4.14"
                            }
                        ]
                    },
                    {
                        "featureType": "road.arterial",
                        "elementType": "labels.icon",
                        "stylers": [
                            {
                                "visibility": "off"
                            }
                        ]
                    },
                    {
                        "featureType": "transit",
                        "elementType": "all",
                        "stylers": [
                            {
                                "visibility": "off"
                            }
                        ]
                    },
                    {
                        "featureType": "water",
                        "elementType": "all",
                        "stylers": [
                            {
                                "visibility": "on"
                            },
                            {
                                "hue": "#0073ff"
                            },
                            {
                                "saturation": "-70"
                            },
                            {
                                "lightness": "-24"
                            },
                            {
                                "gamma": "1"
                            }
                        ]
                    }
                ]);
            };
            this.showMarkers = function () {
                _this.showMarkersCallbackCount += 1;
                var bounds = _this.map.getBounds().toJSON();
                if (_this.showMarkersCallbackCount > 1) {
                    app.trigger(constants.DASHBOARD_MAP_BOUNDS_CHANGED, bounds);
                }
            };
            this.getGroupedAndOrderedEventsByCategory = function (events) {
                var selectedCategories = FilterOptions.getCategories();
                var groupedEventsByCatgory = _.groupBy(events, function (e) { return e.eventCategory.id; });
                //must set the order based on the selectedCategories
                var orderedAndGroupedEventsByCategory = [];
                if (selectedCategories.length > 0) {
                    for (var i = 0; i < selectedCategories.length; i++) {
                        orderedAndGroupedEventsByCategory.push(groupedEventsByCatgory[selectedCategories[i]]);
                    }
                }
                else {
                    orderedAndGroupedEventsByCategory = groupedEventsByCatgory;
                }
                return orderedAndGroupedEventsByCategory;
            };
            //I want to limit the amount of times we are required to call googles api to get zoom points, so I'm using localstorage.
            this.getMapZoomPosition = function () {
                var def = $.Deferred();
                var MAP_ZOOM_LOCATION = 'mapZoomLocation';
                if (!localStorage.getItem(MAP_ZOOM_LOCATION)) {
                    DashboardService.dashboardService.getDepartmentInfo()
                        .done(function (data) {
                        _this.mapZoomCoordinates = data.location; //{lat: x, lng:y}
                        localStorage.setItem(MAP_ZOOM_LOCATION, JSON.stringify(_this.mapZoomCoordinates));
                        def.resolve();
                    }).fail(function () {
                        def.reject();
                    });
                }
                else {
                    _this.mapZoomCoordinates = JSON.parse(localStorage.getItem(MAP_ZOOM_LOCATION));
                    def.resolve();
                }
                return def.promise();
            };
            //if we choose to use heatmaps, this will generate the heatmap for us
            this.getPointsForHeatMap = function (events) {
                var array = [];
                _.each(events, function (event) {
                    array.push(new gmaps.LatLng(event.latitude, event.longitude));
                });
                return array;
            };
            this.events = events;
            this.isShowingAllCategories = isShowingAllCategories;
        }
        return EventMap;
    })();
    return EventMap;
});
//# sourceMappingURL=eventMap.js.map