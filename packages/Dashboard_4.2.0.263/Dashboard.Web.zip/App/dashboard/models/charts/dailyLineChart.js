define(["require", "exports"], function (require, exports) {
    var DailyLineChart = (function () {
        function DailyLineChart(domId, colorIndexOffset) {
            var _this = this;
            this.redraw = function (seriesData) {
                _this.chart.series[0].setData(seriesData[0].data);
                _.each(seriesData, function (element, i) {
                    _this.chart.series[i].setData(seriesData[i].data);
                });
            };
            this.addSeries = function (seriesData) {
                seriesData['fillColor'] = _this.getFillColor(_this.chart.series.length);
                //this adds 1 at a time. If I want to add n items, loop and add
                _this.chart.addSeries(seriesData, false);
                _this.chart.redraw();
            };
            this.removeSeries = function (officerIndex) {
                //remove last element in series
                if (_this.chart.series.length > 1) {
                    _this.chart.series[officerIndex].remove();
                }
            };
            //todo: reuse this
            this.getFillColor = function (index) {
                var color = Highcharts.Color(Highcharts.getOptions().colors[index + _this.colorIndexOffset]);
                return {
                    linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                    stops: [
                        [0, color.setOpacity(.2).get('rgba')],
                        [1, color.setOpacity(0).get('rgba')]
                    ]
                };
            };
            this.buildChart = function (seriesData) {
                var sData = [];
                //build gradients for each element in series
                _.each(seriesData, function (data, index) {
                    var color = Highcharts.Color(Highcharts.getOptions().colors[index + _this.colorIndexOffset]);
                    sData.push({
                        name: data.name,
                        color: color.input,
                        fillColor: {
                            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                            stops: [
                                [0, color.setOpacity(.2).get('rgba')],
                                [1, color.setOpacity(0).get('rgba')]
                            ]
                        },
                        data: data.data
                    });
                });
                _this.chart = $(_this.domId).highcharts({
                    chart: {
                        type: 'areaspline',
                        marginTop: 60
                    },
                    title: {
                        text: ''
                    },
                    legend: {
                        enabled: false
                    },
                    //legend: {
                    //    layout: 'vertical',
                    //    align: 'left',
                    //    verticalAlign: 'top',
                    //    x: 150,
                    //    y: 100,
                    //    floating: true,
                    //    borderWidth: 1,
                    //    backgroundColor: '#FFFFFF'
                    //},
                    xAxis: {
                        type: 'datetime',
                        plotBands: [{
                                from: 4.5,
                                to: 6.5,
                                color: 'rgba(68, 170, 213, .2)'
                            }]
                    },
                    yAxis: {
                        title: {
                            text: ''
                        }
                    },
                    tooltip: {
                        shared: true,
                        valueSuffix: ' events'
                    },
                    credits: {
                        enabled: false
                    },
                    series: sData
                });
                _this.chart = $(_this.domId).highcharts();
            };
            this.buildMonthlyAggregateChart = function (data) {
                var sData = [];
                _.each(data.seriesData, function (data, index) {
                    var color = Highcharts.Color(Highcharts.getOptions().colors[index + _this.colorIndexOffset]);
                    sData.push({
                        name: data.name,
                        color: color.input,
                        fillColor: {
                            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                            stops: [
                                [0, color.setOpacity(.2).get('rgba')],
                                [1, color.setOpacity(0).get('rgba')]
                            ]
                        },
                        data: data.data
                    });
                });
                _this.chart = $(_this.domId).highcharts({
                    chart: {
                        type: 'areaspline',
                        marginTop: 60
                    },
                    title: {
                        text: ''
                    },
                    xAxis: {
                        //categories must be in folowing format, categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', .....]
                        categories: data.months,
                        plotBands: [{
                                //from: 4.5,
                                //to: 6.5,
                                color: 'rgba(68, 170, 213, .2)'
                            }]
                    },
                    yAxis: {
                        title: {
                            text: ''
                        }
                    },
                    tooltip: {
                        shared: true,
                        valueSuffix: ' events'
                    },
                    legend: {
                        enabled: false
                    },
                    credits: {
                        enabled: false
                    },
                    series: sData
                });
                _this.chart = $(_this.domId).highcharts();
            };
            this.domId = domId;
            this.colorIndexOffset = colorIndexOffset ? colorIndexOffset : 0;
        }
        return DailyLineChart;
    })();
    return DailyLineChart;
});
//# sourceMappingURL=dailyLineChart.js.map