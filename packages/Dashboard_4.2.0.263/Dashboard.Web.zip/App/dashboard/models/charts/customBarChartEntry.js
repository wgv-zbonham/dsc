define(["require", "exports"], function (require, exports) {
    var CustomBarChartEntry = (function () {
        function CustomBarChartEntry() {
        }
        return CustomBarChartEntry;
    })();
    return CustomBarChartEntry;
});
//# sourceMappingURL=customBarChartEntry.js.map