var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "dashboard/models/charts/hourlyBarChart"], function (require, exports, HourlyBarChart) {
    var OfficerEventsHourlyBarChart = (function (_super) {
        __extends(OfficerEventsHourlyBarChart, _super);
        function OfficerEventsHourlyBarChart(officers, domId, timeFrame) {
            var _this = this;
            _super.call(this, domId);
            this.build = function (timeFrame, hourlyStats) {
                _this.selectedTimeFrame = timeFrame;
                _this.buildChart(_this.getHourlySeries(hourlyStats));
            };
            this.updateSeriesData = function (officers, hourlyStats) {
                _this.officers = officers;
                _this.redraw(_this.getHourlySeries(hourlyStats));
            };
            this.addToChart = function (officer, timeFrame) {
                var seriesData = {
                    name: officer.firstName,
                    data: _this.getRandomHourlySeriesData()
                };
                _this.addSeries(seriesData);
            };
            this.getHourlySeries = function (hourlyStats) {
                var seriesData = [];
                var initialSecondaryColorIndex = 3;
                _.each(hourlyStats, function (entry, index) {
                    var entries = [];
                    _.each(entry.hourEntries, function (hourEntry) {
                        entries.push(hourEntry);
                    });
                    var color = Highcharts.Color(Highcharts.getOptions().colors[index + initialSecondaryColorIndex]);
                    var name = (entry.officer.firstName === "All" && entry.officer.lastName === "Officers") ? "All Officers" : entry.officer.shortFullName;
                    seriesData.push({
                        name: name,
                        color: color.input,
                        data: entries
                    });
                });
                return seriesData;
            };
            this.officers = officers;
            this.selectedTimeFrame = timeFrame;
        }
        return OfficerEventsHourlyBarChart;
    })(HourlyBarChart);
    return OfficerEventsHourlyBarChart;
});
//# sourceMappingURL=officerEventsHourlyBarChart.js.map