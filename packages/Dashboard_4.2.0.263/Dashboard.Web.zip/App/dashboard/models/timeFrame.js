define(["require", "exports"], function (require, exports) {
    var TimeFrame;
    (function (TimeFrame) {
        TimeFrame[TimeFrame["SevenDays"] = 7] = "SevenDays";
        TimeFrame[TimeFrame["ThirtyDays"] = 30] = "ThirtyDays";
        TimeFrame[TimeFrame["TwelveMonths"] = 365] = "TwelveMonths";
    })(TimeFrame || (TimeFrame = {}));
    return TimeFrame;
});
//# sourceMappingURL=timeFrame.js.map