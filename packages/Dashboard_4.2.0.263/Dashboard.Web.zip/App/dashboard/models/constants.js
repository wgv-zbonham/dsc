define(["require", "exports"], function (require, exports) {
    var Constants = (function () {
        function Constants() {
        }
        Constants.ADD_DASBOARD_FILTER_OPTION = 'dashboard:addFilterOption';
        Constants.DASBOARD_RELOAD_FILTER_CONTROL = 'dashboard:reloadFilterControl';
        Constants.DASHBOARD_OFFICER_WIDGET_OFFICER_CLICKED = 'dashboard:officerWidgetOfficerClicked';
        Constants.REMOVE_DASBOARD_FILTER_OPTION = 'dashboard:removeFilterOption';
        Constants.DASHBOARD_TIME_FRAME_CHANGED = 'dashboard:timeFrameChanged';
        Constants.DASHBOARD_CATEGORY_SELECTION_CHANGED = 'dashboard:categorySelectionChanged';
        Constants.DASHBOARD_OFFICER_SELECTION_CHANGED = 'dashboard:officerSelectionChanged';
        Constants.DASHBOARD_FILTER_OPTIONS_DATA_LOADED = 'dashboard:filter_options_data_loaded';
        Constants.DASHBOARD_MAP_FAILED_TO_LOAD = 'dashboard:map_failed_to_load';
        Constants.DASHBOARD_MAP_BOUNDS_CHANGED = 'dashboard:map_bounds_changed';
        return Constants;
    })();
    return Constants;
});
//# sourceMappingURL=constants.js.map