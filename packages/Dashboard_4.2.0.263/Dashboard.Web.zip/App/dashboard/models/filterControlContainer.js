define(["require", "exports", "dashboard/models/filterOptions", "dashboard/services/dashboardService"], function (require, exports, FilterOptions, DashboardService) {
    var FilterControlContainer = (function () {
        function FilterControlContainer() {
            var _this = this;
            this.filterControlData = {
                filteredOfficersTotal: 0,
                filteredCategoriesTotal: 0,
                officers: [],
                officerCount: 0,
                availableCategories: [],
                availableOfficers: []
            };
            this.loadFilteredControlData = function () {
                return DashboardService.dashboardService.getFilterOptions(null)
                    .then(function (data) {
                    _this.filterControlData.officerCount = data.officerCount;
                    _this.filterControlData.availableOfficers = data.officers;
                    _this.filterControlData.availableCategories = data.categories;
                    var selectedCategories = FilterOptions.getCategories();
                    var selectedOfficers = FilterOptions.getOfficers();
                    return DashboardService.dashboardService.getOfficerAggregateCatageorySummaries(FilterOptions.getTimeFrame(), selectedCategories, selectedOfficers);
                }).then(function (data) {
                    _this.filterControlData.officers = data.officers;
                    _this.filterControlData.filteredCategoriesTotal = data.categoryCount;
                    _this.filterControlData.filteredOfficersTotal = data.officerCount;
                });
            };
        }
        return FilterControlContainer;
    })();
    return FilterControlContainer;
});
//# sourceMappingURL=filterControlContainer.js.map