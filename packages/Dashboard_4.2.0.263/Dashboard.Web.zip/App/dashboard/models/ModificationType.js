define(["require", "exports"], function (require, exports) {
    var ModificaitonType;
    (function (ModificaitonType) {
        ModificaitonType[ModificaitonType["Update"] = 0] = "Update";
        ModificaitonType[ModificaitonType["Add"] = 1] = "Add";
        ModificaitonType[ModificaitonType["Remove"] = 2] = "Remove";
    })(ModificaitonType || (ModificaitonType = {}));
    return ModificaitonType;
});
//# sourceMappingURL=ModificationType.js.map