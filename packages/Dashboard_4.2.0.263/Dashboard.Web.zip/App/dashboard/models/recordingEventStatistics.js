define(["require", "exports"], function (require, exports) {
    var RecordingEventStatistics = (function () {
        //not sure if it makes more sense to pass any or RecordingEventStatistics to constructor here
        function RecordingEventStatistics(eventStats) {
            if (eventStats) {
                this.uploadedCritical = eventStats.uploadedCritical;
                this.uploadedNonCritical = eventStats.uploadedNonCritical;
                this.uploadedUnknown = eventStats.uploadedUnknown;
                this.uploadedSizeCritical = eventStats.uploadedSizeCritical;
                this.uploadedSizeNonCritical = eventStats.uploadedSizeNonCritical;
                this.uploadedSizeTotal = eventStats.uploadedSizeTotal;
                this.durationCritical = eventStats.durationCritical;
                this.durationNonCritical = eventStats.durationNonCritical;
                this.playedCritical = eventStats.playedCritical;
                this.playedNonCritical = eventStats.playedNonCritical;
                this.upcomingDeletionsCritical = eventStats.upcomingDeletionsCritical;
                this.upcomingDeletionsNonCritical = eventStats.upcomingDeletionsNonCritical;
                this.casesCreated = eventStats.casesCreated;
                this.shares = eventStats.shares;
                this.officerCount = eventStats.officerCount;
                this.categoryCount = eventStats.categoryCount;
            }
        }
        RecordingEventStatistics.prototype.getUploadedTotal = function () {
            return this.uploadedCritical + this.uploadedNonCritical;
        };
        RecordingEventStatistics.prototype.getDurationTotal = function () {
            return this.durationCritical + this.durationNonCritical;
        };
        RecordingEventStatistics.prototype.getPlayedTotal = function () {
            return this.playedCritical + this.playedNonCritical;
        };
        RecordingEventStatistics.prototype.getUpcomingDeletionsTotal = function () {
            return this.upcomingDeletionsCritical + this.upcomingDeletionsNonCritical;
        };
        return RecordingEventStatistics;
    })();
    return RecordingEventStatistics;
});
//# sourceMappingURL=recordingEventStatistics.js.map