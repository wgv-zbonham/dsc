define(["require", "exports"], function (require, exports) {
    var ActivityFeedEntry = (function () {
        function ActivityFeedEntry() {
        }
        return ActivityFeedEntry;
    })();
    return ActivityFeedEntry;
});
//# sourceMappingURL=activityFeedEntry.js.map