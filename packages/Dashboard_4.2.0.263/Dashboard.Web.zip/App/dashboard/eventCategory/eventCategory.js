var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", 'durandal/app', 'plugins/router', "dashboard/models/constants", "dashboard/models/timeFrame", "dashboard/models/charts/eventCategoryDailyLineChart", "dashboard/models/charts/eventCategoryHourlyBarChart", "dashboard/models/ModificationType", "dashboard/services/dashboardService", "dashboard/models/filterOptions", "dashboard/models/statistician", "dashboard/models/filterControlContainer"], function (require, exports, app, router, constants, TimeFrame, EventCategoryDailyLineChart, EventCategoryHourlyBarChart, ModificationType, DashboardService, FilterOptions, Statistician, FilterControlContainer) {
    var EventCategory = (function (_super) {
        __extends(EventCategory, _super);
        function EventCategory() {
            var _this = this;
            _super.apply(this, arguments);
            this.timeFrameOptions = [];
            this.currentTimeFrame = TimeFrame.ThirtyDays;
            this.selectedEventCategorySummaries = [];
            this.selectedOfficers = [];
            this.availableCategories = [];
            this.isViewingDetails = false;
            this.categorySeriesData = [];
            this.appSubscriptions = [];
            this.filterOptions = FilterOptions;
            this.activate = function () {
                _this.handleRoutedCategoryId();
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_TIME_FRAME_CHANGED).then(function (data) {
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.getActivityTypeSummaries();
                    _this.timeFrameSelectionChanged(data.timeFrame);
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_CATEGORY_SELECTION_CHANGED).then(function (data) {
                    _this.selectedEventCategorySummaries = data.selectedCategories;
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.getActivityTypeSummaries();
                    _this.loadCategories();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_OFFICER_SELECTION_CHANGED).then(function (data) {
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.getActivityTypeSummaries();
                    _this.loadCategories();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_FILTER_OPTIONS_DATA_LOADED).then(function (data) {
                    _this.currentTimeFrame = data.timeFrame;
                    _this.selectedEventCategorySummaries = data.selectedCategories;
                    _this.selectedOfficers = data.selectedOfficers;
                }));
                //must return here, we are relying on promise to return before compositioncomplete
                return $.when(_this.getActivityTypeSummaries(), _this.loadFilteredControlData());
            };
            this.compositionComplete = function () {
                _this.loadCategories();
            };
            this.detached = function () {
                _.forEach(_this.appSubscriptions, function (sub) { return sub.off(); });
                _this.appSubscriptions.length = 0;
            };
            this.onOverviewClicked = function () {
                _this.isViewingDetails = false;
                _this.bindCharts();
                return true;
            };
            this.onDetailsClicked = function () {
                _this.isViewingDetails = true;
                return true;
            };
            this.timeFrameSelectionChanged = function (timeFrame) {
                _this.currentTimeFrame = timeFrame;
                _this.getStatistics(ModificationType.Update);
            };
            this.getReadableTimeFrameText = function () {
                var unit = (_this.currentTimeFrame === TimeFrame.ThirtyDays || _this.currentTimeFrame === TimeFrame.SevenDays) ? " Days" : " Months";
                var unitCount = _this.currentTimeFrame === TimeFrame.TwelveMonths ? 12 : _this.currentTimeFrame;
                return " Last " + unitCount + unit;
            };
            this.isShowingActivitySummaryBreakdowns = function () {
                var selectedCategoryIds = _this.filterOptions.getCategories(); //uses ordered categoryIds
                return selectedCategoryIds.length > 1;
            };
            this.getActivityTypeSummaries = function () {
                return DashboardService.dashboardService.getActivityTypeStatistics(_this.filterOptions.getTimeFrame(), 2, //2=Categories
                _this.filterOptions.getCategories(), _this.filterOptions.getOfficers()).then(function (result) {
                    _this.recordingEventStatistics = Statistician.statistician.getOrderedActivityTypesByCategory(result, _this.filterOptions.getCategories());
                });
            };
            this.bindCharts = function () {
                DashboardService.dashboardService.getDailyCategoryCounts(_this.currentTimeFrame, _this.selectedEventCategorySummaries, _this.selectedOfficers).then(function (data) {
                    _this.eventCategoryDailyLineChart.build(data.dailyStats, _this.currentTimeFrame);
                    _this.eventCategoryHourlyBarChart.build(data.hourlyStats);
                });
            };
            this.getStatistics = function (modType) {
                DashboardService.dashboardService.getDailyCategoryCounts(_this.currentTimeFrame, _this.selectedEventCategorySummaries, _this.selectedOfficers).then(function (data) {
                    if (modType === ModificationType.Update) {
                        _this.eventCategoryDailyLineChart.build(data.dailyStats, _this.currentTimeFrame);
                        _this.eventCategoryHourlyBarChart.updateSeriesData(data.hourlyStats);
                    }
                });
            };
            this.loadCategories = function () {
                _this.eventCategoryDailyLineChart = new EventCategoryDailyLineChart(_this.selectedEventCategorySummaries, '#categoryDailyGraph');
                _this.eventCategoryHourlyBarChart = new EventCategoryHourlyBarChart(_this.selectedEventCategorySummaries, '#hourlyGraph');
                _this.bindCharts();
            };
            this.handleRoutedCategoryId = function () {
                var categoryId = router.activeInstruction().params[0] ? parseInt(router.activeInstruction().params[0].id) : null;
                if (categoryId != null) {
                    _this.filterOptions.setCategories([categoryId]);
                    app.trigger(constants.DASBOARD_RELOAD_FILTER_CONTROL);
                }
            };
        }
        return EventCategory;
    })(FilterControlContainer);
    return EventCategory;
});
//# sourceMappingURL=eventCategory.js.map