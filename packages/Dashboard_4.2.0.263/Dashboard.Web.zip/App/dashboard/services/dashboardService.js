define(["require", "exports", "dashboard/models/officer", "dashboard/models/recordingEventStatistics", "dashboard/models/activityTypeSummaries", "dashboard/models/applicationPaths"], function (require, exports, Officer, RecordingEventStatistics, ActivityTypeSummaries, ApplicationPaths) {
    var DashboardService = (function () {
        function DashboardService() {
            var _this = this;
            this.getFilterOptions = function (search) {
                var queryString = search ? "?search=" + encodeURIComponent(search) : "";
                return _this.invokeApiGet('/api/options/filters' + queryString)
                    .then(function (data) {
                    _.each(data.officers, function (officer) {
                        new Officer(officer).map(officer);
                    });
                    return data;
                });
            };
            this.getOfficerAggregateCatageorySummaries = function (days, categories, officers) {
                var queryString = _this.buildQueryStringFromIds(days, officers, categories);
                return _this.invokeApiGet('/api/statistics/officerAggregate/days/' + queryString)
                    .then(function (data) {
                    _.each(data.officers, function (officer) {
                        new Officer(officer).map(officer);
                    });
                    return data;
                });
            };
            this.getDailyOfficerEventCounts = function (days, categories, officers) {
                var queryString = _this.buildQueryStringFromObjects(days, officers, categories);
                return _this.invokeApiGet('/api/statistics/dailyOfficerEvents/days/' + queryString)
                    .then(function (data) {
                    _.each(data.dailyStats, function (dailyStat) {
                        new Officer(dailyStat.officer).map(dailyStat.officer);
                    });
                    _.each(data.hourlyStats, function (hourlyStats) {
                        new Officer(hourlyStats.officer).map(hourlyStats.officer);
                    });
                    return data;
                });
            };
            this.getDailyCategoryCounts = function (days, categories, officers) {
                var queryString = _this.buildQueryStringFromObjects(days, officers, categories);
                return _this.invokeApiGet('/api/statistics/dailyCategoryEvents/days/' + queryString);
            };
            this.getCategoryAggregateForAllOfficers = function (days, categories) {
                var queryString = days + "?";
                queryString = _this.appendCategories(categories, queryString);
                return _this.invokeApiGet('/api/statistics/categoryAggregate/days/' + queryString);
            };
            this.getActivityFeedStatistics = function (days, categories, officers) {
                var queryString = _this.buildQueryStringFromIds(days, officers, categories);
                return _this.invokeApiGet('/api/activityFeeds/days/' + queryString)
                    .then(function (data) {
                    data = new RecordingEventStatistics(data);
                    return data;
                });
            };
            this.getRecordingEvents = function (days, categories, officers, bounds) {
                var queryString = _this.buildQueryStringFromObjects(days, officers, categories);
                if (bounds) {
                    var boundsCSV = bounds.south + "," + bounds.west + "," + bounds.north + "," + bounds.east;
                    var appendingValue = "";
                    if (categories && categories.length > 0 || officers && officers.length > 0) {
                        appendingValue = "&";
                    }
                    else {
                        appendingValue = "?";
                    }
                    queryString = queryString + appendingValue + "bounds=" + boundsCSV;
                }
                return _this.invokeApiGet('/api/RecordingEvents/days/' + queryString).then(function (events) {
                    _.each(events, function (event) {
                        if (event.officer) {
                            new Officer(event.officer).map(event.officer);
                        }
                    });
                    return events;
                });
            };
            this.getDepartmentInfo = function () {
                return _this.invokeApiGet('/api/departments')
                    .then(function (department) {
                    return _this.getMapCoordinatesFromGoogle(department);
                });
            };
            this.getApplicationPaths = function () {
                return _this.invokeApiGet('/api/departments/applicationPaths');
            };
            this.attemptCookieRefresh = function () {
                return _this.invokeApiPut('/api/accounts/cookie');
            };
            this.getActivityTypeStatistics = function (days, filterType, categories, officers) {
                var queryString = _this.buildQueryStringFromIds(days, officers, categories);
                if (queryString.substr(queryString.length - 1) !== "?") {
                    if ((officers && officers.length > 0) || (categories && categories.length > 0)) {
                        queryString += "&";
                    }
                    else {
                        queryString += "?";
                    }
                }
                //1=Officers, 2=Categories
                queryString += "filterType=" + filterType;
                return _this.invokeApiGet('/api/statistics/activityTypeStatistics/days/' + queryString)
                    .then(function (data) {
                    data = new ActivityTypeSummaries(data);
                    return data;
                });
            };
            this.getLoginPathToElWeb = function () {
                return ApplicationPaths.getElWebPath() + "/Account/Login?ReturnUrl=" + ApplicationPaths.getDashboardPath();
            };
        }
        DashboardService.prototype.invokeApiGet = function (url) {
            var self = this;
            return $.ajax({
                type: 'GET',
                contentType: "application/json; charset=utf-8",
                url: url,
                statusCode: {
                    401: function (jqXHR, textStatus, errorThrown) {
                        self.handlUnauthorizedHttpStatusCode();
                    }
                }
            });
        };
        DashboardService.prototype.invokeApiPut = function (url, data) {
            if (data === void 0) { data = null; }
            var self = this;
            return $.ajax({
                type: 'PUT',
                contentType: "application/json; charset=utf-8",
                url: url,
                dataType: 'json',
                data: data,
                statusCode: {
                    401: function (jqXHR, textStatus, errorThrown) {
                        self.handlUnauthorizedHttpStatusCode();
                    }
                }
            });
        };
        DashboardService.prototype.handlUnauthorizedHttpStatusCode = function () {
            localStorage.clear();
            window.location.href = this.getLoginPathToElWeb();
        };
        DashboardService.prototype.getMapCoordinatesFromGoogle = function (data) {
            var departmentInfo = data;
            return $.ajax({
                type: 'GET',
                url: 'https://maps.googleapis.com/maps/api/geocode/json?address=' + data.location + '&key=AIzaSyCu9Dc18r5kno73g56aiT5xfOQzWW3UWiU'
            })
                .then(function (data) {
                departmentInfo.location = data.results[0].geometry.location;
                return departmentInfo;
            })
                .fail(function () {
                console.log('failed to get address: ' + data.location + ' from google api at https://maps.googleapis.com/maps/api/geocode/json?address=');
            });
        };
        //this appends category ids when given a collection CategorySummary objects
        DashboardService.prototype.appendCategories = function (catgories, queryString) {
            if (catgories) {
                _.each(catgories, function (category) {
                    if (category) {
                        if (queryString.substr(queryString.length - 1) !== "?") {
                            queryString += "&";
                        }
                        queryString += "eventCategoryIds=" + category.id;
                    }
                });
            }
            return queryString;
        };
        DashboardService.prototype.appendOfficers = function (officers, queryString) {
            if (officers) {
                _.each(officers, function (officer) {
                    if (officer) {
                        if (queryString.substr(queryString.length - 1) !== "?") {
                            queryString += "&";
                        }
                        queryString += "officerIds=" + officer.id;
                    }
                });
            }
            return queryString;
        };
        //this appends category ids when given a collection of numbers for ids
        DashboardService.prototype.appendCategoryIds = function (categories, queryString) {
            if (categories) {
                _.each(categories, function (categoryId) {
                    if (categoryId) {
                        if (queryString.substr(queryString.length - 1) !== "?") {
                            queryString += "&";
                        }
                        queryString += "eventCategoryIds=" + categoryId;
                    }
                });
            }
            return queryString;
        };
        //this appends officer ids when given a collection of numbers for ids
        DashboardService.prototype.appendOfficerIds = function (officers, queryString) {
            if (officers) {
                _.each(officers, function (officerId) {
                    if (officerId && officerId > 0) {
                        if (queryString.substr(queryString.length - 1) !== "?") {
                            queryString += "&";
                        }
                        queryString += "officerIds=" + officerId;
                    }
                });
            }
            return queryString;
        };
        DashboardService.prototype.buildQueryStringFromObjects = function (days, officers, catgories) {
            var queryString = days + "?";
            queryString = this.appendCategories(catgories, queryString);
            queryString = this.appendOfficers(officers, queryString);
            if (queryString.substr(queryString.length - 1) === "?") {
                //in the event that neither officers nor catgories was provided, we will remove the '?' that was previously appended
                queryString = queryString.substring(0, queryString.length - 1);
            }
            return queryString;
        };
        DashboardService.prototype.buildQueryStringFromIds = function (days, officers, catgories) {
            var queryString = days + "?";
            queryString = this.appendCategoryIds(catgories, queryString);
            queryString = this.appendOfficerIds(officers, queryString);
            if (queryString.substr(queryString.length - 1) === "?") {
                //in the event that neither officers nor catgories was provided, we will remove the '?' that was previously appended
                queryString = queryString.substring(0, queryString.length - 1);
            }
            return queryString;
        };
        return DashboardService;
    })();
    exports.dashboardService = new DashboardService();
});
//# sourceMappingURL=dashboardService.js.map