define(["require", "exports"], function (require, exports) {
    var EventCategoryService = (function () {
        function EventCategoryService() {
            this.getEventCategorySummary = function (officers) {
                //todo: pass officers into api and remove hard-coded values
                var def = $.Deferred();
                setTimeout(function () {
                    //todo: create random number
                    var officersCategorySummaries = [];
                    officersCategorySummaries.push([
                        { name: "Critical", count: 240 },
                        { name: "Non Critical", count: 240 },
                        { name: "Domestic", count: 137 },
                        { name: "Arrest", count: 69 },
                        { name: "Traffic Accident", count: 66 },
                        { name: "Injury", count: 55 },
                        { name: "D.U.I.", count: 51 },
                        { name: "Traffic Citation", count: 50 },
                        { name: "Assault", count: 35 },
                        { name: "Motorist Assist", count: 29 }
                    ]);
                    if (officers.length > 1) {
                        officersCategorySummaries.push([
                            { name: "Critical", count: 240 },
                            { name: "Non Critical", count: 240 },
                            { name: "Domestic", count: 137 },
                            { name: "Arrest", count: 69 },
                            { name: "Traffic Accident", count: 66 },
                            { name: "Injury", count: 55 },
                            { name: "D.U.I.", count: 51 },
                            { name: "Traffic Citation", count: 50 },
                            { name: "Assault", count: 35 },
                            { name: "Motorist Assist", count: 29 }
                        ]);
                    }
                    def.resolve(officersCategorySummaries);
                }, 500);
                return def.promise();
            };
        }
        return EventCategoryService;
    })();
    exports.eventCategoryService = new EventCategoryService();
});
//# sourceMappingURL=eventCategoryService.js.map