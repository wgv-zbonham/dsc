var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", 'durandal/app', 'plugins/router', "dashboard/models/constants", "dashboard/models/timeFrame", "dashboard/services/dashboardService", "dashboard/models/charts/officerEventsDailyLineChart", "dashboard/models/charts/officerEventsHourlyBarChart", "dashboard/models/ModificationType", "dashboard/models/charts/customBarChartService", "dashboard/models/officer", "dashboard/models/filterOptions", "dashboard/models/statistician", "dashboard/models/filterControlContainer"], function (require, exports, app, router, constants, TimeFrame, DashboardService, OfficerEventsDailyLineChart, OfficerEventsHourlyBarChart, ModificationType, CustomBarChartService, Officer, FilterOptions, Statistician, FilterControlContainer) {
    var OfficerEvents = (function (_super) {
        __extends(OfficerEvents, _super);
        function OfficerEvents() {
            var _this = this;
            _super.apply(this, arguments);
            this.timeFrameOptions = [];
            this.currentTimeFrame = TimeFrame.ThirtyDays;
            this.selectedOfficers = [];
            this.unfilteredOfficers = [];
            this.isViewingDetails = false;
            this.categoryChartEntries = [];
            this.availableCategories = [];
            this.selectedCategories = [];
            this.categorySeriesData = [];
            this.appSubscriptions = [];
            this.mockOfficerIdForCharts = -100;
            this.filterOptions = FilterOptions;
            this.activate = function () {
                _this.filteredCategoriesTotal = 0;
                _this.handleRoutedOfficerId();
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_TIME_FRAME_CHANGED).then(function (data) {
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.filteredCategoriesTotal = data.filteredCategoriesTotal;
                    _this.unfilteredOfficers = data.unfilteredOfficers; //we set this in case no officers are selected
                    _this.timeFrameSelectionChanged(data.timeFrame);
                    _this.getActivityTypeSummaries();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_OFFICER_SELECTION_CHANGED).then(function (data) {
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.filteredCategoriesTotal = data.filteredCategoriesTotal;
                    _this.unfilteredOfficers = data.unfilteredOfficers;
                    _this.getActivityTypeSummaries();
                    _this.loadCharts();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_CATEGORY_SELECTION_CHANGED).then(function (data) {
                    _this.selectedCategories = data.selectedCategories;
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.unfilteredOfficers = data.unfilteredOfficers;
                    _this.filteredCategoriesTotal = data.filteredCategoriesTotal;
                    _this.getActivityTypeSummaries();
                    _this.loadCharts();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_FILTER_OPTIONS_DATA_LOADED).then(function (data) {
                    _this.filteredCategoriesTotal = data.filteredCategoriesTotal;
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.unfilteredOfficers = data.unfilteredOfficers;
                    _this.selectedCategories = data.selectedCategories;
                    _this.availableCategories = data.availableCategories;
                    _this.currentTimeFrame = data.timeFrame;
                }));
                //must return here, we are relying on promise to return before compositioncomplete
                return $.when(_this.getActivityTypeSummaries(), _this.loadFilteredControlData());
            };
            this.compositionComplete = function () {
                _this.loadCharts();
            };
            this.detached = function () {
                _.forEach(_this.appSubscriptions, function (sub) { return sub.off(); });
                _this.appSubscriptions.length = 0;
            };
            this.categoryClicked = function (category) {
                window.location.href = "#dashboard/eventCategory?id=" + category.id;
            };
            this.onOverviewClicked = function () {
                _this.isViewingDetails = false;
                _this.bindCharts();
                return true;
            };
            this.onDetailsClicked = function () {
                _this.isViewingDetails = true;
                return true;
            };
            this.isShowingActivitySummaryBreakdowns = function () {
                var selectedOfficerIds = _this.filterOptions.getOfficers(); //uses ordered officerIds
                return selectedOfficerIds.length > 1;
            };
            this.timeFrameSelectionChanged = function (timeFrame) {
                _this.currentTimeFrame = timeFrame;
                _this.getStatistics(ModificationType.Update);
            };
            this.bindCharts = function () {
                DashboardService.dashboardService.getDailyOfficerEventCounts(_this.currentTimeFrame, _this.selectedCategories, _this.selectedOfficers).done(function (data) {
                    _this.officerEventsDailyLineChart.build(data.dailyStats, _this.currentTimeFrame);
                    _this.officerEventsHourlyBarChart.build(_this.currentTimeFrame, data.hourlyStats);
                    var showZeroValues = !(_this.selectedCategories.length <= 0);
                    var categories = _this.selectedCategories.length <= 0 ? _this.availableCategories : _this.selectedCategories;
                    _this.categoryChartEntries = CustomBarChartService.customBarChartService.getCustomCategoryBarChartData(_this.selectedOfficers, categories, showZeroValues);
                });
            };
            this.getStatistics = function (modType) {
                DashboardService.dashboardService.getDailyOfficerEventCounts(_this.currentTimeFrame, _this.selectedCategories, _this.selectedOfficers).then(function (data) {
                    if (_this.selectedOfficers.length === 0) {
                        var officer = new Officer();
                        officer.shortFullName = "All Officers";
                        officer.id = _this.mockOfficerIdForCharts;
                        var categories = _this.selectedCategories.length <= 0 ? null : _this.selectedCategories;
                        DashboardService.dashboardService.getCategoryAggregateForAllOfficers(_this.currentTimeFrame, categories).then(function (categories) {
                            officer.eventCategories = categories;
                            _this.selectedOfficers.push(officer);
                            var showZeroValues = !(_this.selectedCategories.length <= 0);
                            var categoriesToUse = _this.selectedCategories.length <= 0 ? _this.availableCategories : _this.selectedCategories;
                            _this.categoryChartEntries = CustomBarChartService.customBarChartService.getCustomCategoryBarChartData(_this.selectedOfficers, categoriesToUse, showZeroValues);
                            if (modType === ModificationType.Update) {
                                _this.officerEventsDailyLineChart.build(data.dailyStats, _this.currentTimeFrame);
                                _this.officerEventsHourlyBarChart.updateSeriesData(_this.selectedOfficers, data.hourlyStats);
                            }
                            _this.selectedOfficers = [];
                        });
                    }
                    else {
                        var showZeroValues = !(_this.selectedCategories.length <= 0);
                        var categoriesToUse = _this.selectedCategories.length <= 0 ? _this.availableCategories : _this.selectedCategories;
                        _this.categoryChartEntries = CustomBarChartService.customBarChartService.getCustomCategoryBarChartData(_this.selectedOfficers, categoriesToUse, showZeroValues);
                        if (modType === ModificationType.Update) {
                            _this.officerEventsDailyLineChart.build(data.dailyStats, _this.currentTimeFrame);
                            _this.officerEventsHourlyBarChart.updateSeriesData(_this.selectedOfficers, data.hourlyStats);
                        }
                    }
                });
            };
            this.getActivityTypeSummaries = function () {
                return DashboardService.dashboardService.getActivityTypeStatistics(_this.filterOptions.getTimeFrame(), 1, //1 = Officers
                _this.filterOptions.getCategories(), _this.filterOptions.getOfficers()).then(function (result) {
                    _this.activityTypeSummaries = Statistician.statistician.getOrderedActivityTypesByOfficer(result, _this.filterOptions.getOfficers());
                });
            };
            this.loadCharts = function () {
                if (_this.selectedOfficers.length <= 0) {
                    var officer = new Officer();
                    officer.shortFullName = "All Officers";
                    officer.id = _this.mockOfficerIdForCharts;
                    var categories = _this.selectedCategories.length <= 0 ? null : _this.selectedCategories;
                    DashboardService.dashboardService.getCategoryAggregateForAllOfficers(_this.currentTimeFrame, categories).then(function (categories) {
                        officer.eventCategories = categories;
                        _this.selectedOfficers.push(officer);
                        _this.officerEventsDailyLineChart = new OfficerEventsDailyLineChart(_this.selectedOfficers, _this.selectedCategories, '#dailyGraph');
                        _this.officerEventsHourlyBarChart = new OfficerEventsHourlyBarChart(_this.selectedOfficers, '#hourlyGraph', _this.currentTimeFrame);
                        _this.bindCharts();
                    });
                }
                else {
                    _this.officerEventsDailyLineChart = new OfficerEventsDailyLineChart(_this.selectedOfficers, _this.selectedCategories, '#dailyGraph');
                    _this.officerEventsHourlyBarChart = new OfficerEventsHourlyBarChart(_this.selectedOfficers, '#hourlyGraph', _this.currentTimeFrame);
                    _this.bindCharts();
                }
            };
            this.handleRoutedOfficerId = function () {
                var officerId = router.activeInstruction().params[0] ? parseInt(router.activeInstruction().params[0].id) : null;
                if (officerId != null) {
                    _this.filterOptions.setOfficers([officerId]);
                    app.trigger(constants.DASBOARD_RELOAD_FILTER_CONTROL);
                }
            };
            this.getReadableTimeFrameText = function () {
                var unit = (_this.currentTimeFrame === TimeFrame.ThirtyDays || _this.currentTimeFrame === TimeFrame.SevenDays) ? " Days" : " Months";
                var unitCount = _this.currentTimeFrame === TimeFrame.TwelveMonths ? 12 : _this.currentTimeFrame;
                return " Last " + unitCount + unit;
            };
        }
        return OfficerEvents;
    })(FilterControlContainer);
    return OfficerEvents;
});
//# sourceMappingURL=officerEvents.js.map