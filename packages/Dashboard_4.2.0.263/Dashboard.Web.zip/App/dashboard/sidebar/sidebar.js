define(["require", "exports", 'durandal/app', "dashboard/models/constants", "dashboard/services/dashboardService", "dashboard/models/recordingEventStatistics", "dashboard/models/timeFrame", "dashboard/models/filterOptions"], function (require, exports, app, constants, DashboardService, RecordingEventStatistics, TimeFrame, FilterOptions) {
    var SideNav = (function () {
        function SideNav() {
            var _this = this;
            this.appSubscriptions = [];
            this.selectedCategories = [];
            this.selectedOfficers = [];
            this.activate = function () {
                _this.selectedTimeFrame = FilterOptions.getTimeFrame();
                _this.selectedCategories = FilterOptions.getCategories();
                _this.selectedOfficers = FilterOptions.getOfficers();
                var initialStats = {
                    uploadedCritical: 0,
                    uploadedNonCritical: 0,
                    uploadedUnknown: 0,
                    uploadedSizeCritical: 0,
                    uploadedSizeNonCritical: 0,
                    durationCritical: 0,
                    durationNonCritical: 0,
                    playedCritical: 0,
                    playedNonCritical: 0,
                    upcomingDeletionsCritical: 0,
                    upcomingDeletionsNonCritical: 0,
                    casesCreated: 0,
                    shares: 0,
                    officerCount: 0,
                    categoryCount: 0
                };
                _this.eventStats = new RecordingEventStatistics(initialStats);
                _this.addSubscriptions();
                _this.getActivityFeedStatistics();
            };
            this.detached = function () {
                _.forEach(_this.appSubscriptions, function (sub) { return sub.off(); });
                _this.appSubscriptions.length = 0;
            };
            this.getFormattedTime = function (seconds) {
                return seconds > 3600 ? moment().startOf('day').seconds(seconds).format('HH:mm:ss') : moment().startOf('day').seconds(seconds).format('mm:ss');
            };
            this.getReadableTimeFrameText = function () {
                var unit = (_this.selectedTimeFrame === TimeFrame.ThirtyDays || _this.selectedTimeFrame === TimeFrame.SevenDays) ? " Days" : " Months";
                var unitCount = _this.selectedTimeFrame === TimeFrame.TwelveMonths ? 12 : _this.selectedTimeFrame;
                return "Last " + unitCount + unit;
            };
            this.getActivityFeedStatistics = function () {
                DashboardService.dashboardService.getActivityFeedStatistics(_this.selectedTimeFrame, _this.selectedCategories, _this.selectedOfficers)
                    .done(function (feedResult) {
                    _this.eventStats = feedResult;
                });
            };
            this.addSubscriptions = function () {
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_TIME_FRAME_CHANGED).then(function (data) {
                    _this.selectedTimeFrame = data.timeFrame;
                    _this.getActivityFeedStatistics();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_CATEGORY_SELECTION_CHANGED).then(function (data) {
                    var categories = [];
                    _.each(data.selectedCategories, function (category) {
                        categories.push(category.id);
                    });
                    _this.selectedCategories = categories;
                    _this.getActivityFeedStatistics();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_OFFICER_SELECTION_CHANGED).then(function (data) {
                    var officers = [];
                    _.each(data.selectedOfficers, function (officer) {
                        officers.push(officer.id);
                    });
                    _this.selectedOfficers = officers;
                    _this.getActivityFeedStatistics();
                }));
            };
        }
        return SideNav;
    })();
    return SideNav;
});
//# sourceMappingURL=sidebar.js.map