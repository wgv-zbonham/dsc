var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", 'durandal/app', "dashboard/models/constants", "dashboard/models/officer", "dashboard/services/dashboardService", "dashboard/models/charts/eventMap", "dashboard/models/charts/customBarChartService", "dashboard/models/filterControlContainer"], function (require, exports, app, constants, Officer, DashboardService, EventMap, CustomBarChartService, FilterControlContainer) {
    var SupervisorDashboard = (function (_super) {
        __extends(SupervisorDashboard, _super);
        function SupervisorDashboard() {
            var _this = this;
            _super.apply(this, arguments);
            this.officers = [];
            this.selectedOfficers = [];
            this.unfilteredOfficers = [];
            this.timeFrameOptions = [];
            this.officerChartEntries = [];
            this.categoryChartEntries = [];
            this.availableCategories = [];
            this.selectedCategories = [];
            this.mapFailedToLoad = false;
            this.filteredOfficersTotal = 0;
            this.currentMapZoomTotal = 0;
            this.appSubscriptions = [];
            this.activate = function () {
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_TIME_FRAME_CHANGED).then(function (data) {
                    _this.currentTimeFrame = data.timeFrame;
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.filteredOfficersTotal = data.filteredOfficersTotal;
                    _this.filteredCategoriesTotal = data.filteredCategoriesTotal;
                    _this.unfilteredOfficers = data.unfilteredOfficers; //we set this in case no officers are selected
                    _this.bindCharts();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_CATEGORY_SELECTION_CHANGED).then(function (data) {
                    _this.selectedCategories = data.selectedCategories;
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.unfilteredOfficers = data.unfilteredOfficers;
                    _this.filteredOfficersTotal = data.filteredOfficersTotal;
                    _this.filteredCategoriesTotal = data.filteredCategoriesTotal;
                    _this.bindCharts();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_OFFICER_SELECTION_CHANGED).then(function (data) {
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.unfilteredOfficers = data.unfilteredOfficers;
                    _this.filteredOfficersTotal = data.filteredOfficersTotal;
                    _this.filteredCategoriesTotal = data.filteredCategoriesTotal;
                    _this.bindCharts();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_MAP_FAILED_TO_LOAD).then(function () {
                    _this.mapFailedToLoad = true;
                    console.log('Unable to load google map. Check internet connection.');
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_FILTER_OPTIONS_DATA_LOADED).then(function (data) {
                    _this.selectedOfficers = data.selectedOfficers;
                    _this.unfilteredOfficers = data.unfilteredOfficers;
                    _this.selectedCategories = data.selectedCategories;
                    _this.availableCategories = data.availableCategories;
                    _this.currentTimeFrame = data.timeFrame;
                    _this.filteredOfficersTotal = data.filteredOfficersTotal;
                    _this.filteredCategoriesTotal = data.filteredCategoriesTotal;
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_MAP_BOUNDS_CHANGED).then(function (bounds) {
                    DashboardService.dashboardService.getRecordingEvents(_this.currentTimeFrame, _this.selectedCategories, _this.selectedOfficers, bounds).then(function (events) {
                        _this.eventMap.addMarkers(events);
                        _this.currentMapZoomTotal = events.length;
                    });
                }));
                //must return here, we are relying on promise to return before compositioncomplete
                return _this.loadFilteredControlData();
            };
            this.compositionComplete = function () {
                _this.bindCharts();
            };
            this.detached = function () {
                _.forEach(_this.appSubscriptions, function (sub) { return sub.off(); });
                _this.appSubscriptions.length = 0;
            };
            this.timeFrameSelectionChanged = function () {
                _this.bindCharts();
            };
            this.officerClicked = function (officer) {
                app.trigger(constants.DASHBOARD_OFFICER_WIDGET_OFFICER_CLICKED, officer);
            };
            this.hasOfficerChartEntries = function () {
                return _this.officerChartEntries.length > 0;
            };
            this.showOfficerWidgetFooterMessage = function () {
                return _this.filteredOfficersTotal > 0;
            };
            this.getFilteredOfficersTotal = function () {
                return _this.officerChartEntries.length > _this.filteredOfficersTotal ? _this.officerChartEntries.length : _this.filteredOfficersTotal;
            };
            this.showZoomMessage = function () {
                return _this.currentMapZoomTotal === 1000;
            };
            this.getOfficerViewingTotal = function () {
                if (_this.selectedOfficers.length > 0) {
                    return _this.filteredOfficersTotal;
                }
                else {
                    return (_this.officerChartEntries.length <= _this.filteredOfficersTotal) ? _this.officerChartEntries.length : _this.filteredOfficersTotal;
                }
            };
            this.getCustomCategoryWidgetData = function () {
                return { chartEntries: _this.categoryChartEntries, categoryTotal: _this.filteredCategoriesTotal };
            };
            this.isShowingAllCategories = function () {
                return _this.selectedCategories.length <= 0;
            };
            this.bindCharts = function () {
                //initially set categories and officers to empty array if there is no selected values, this way we don't pass them to api
                var categories = _this.isShowingAllCategories() ? [] : _this.selectedCategories;
                var officers = _this.selectedOfficers.length <= 0 ? [] : _this.selectedOfficers;
                DashboardService.dashboardService.getRecordingEvents(_this.currentTimeFrame, categories, officers, null)
                    .then(function (events) {
                    _this.buildMap(events);
                    _this.currentMapZoomTotal = events.length;
                });
                categories = _this.isShowingAllCategories() ? _this.availableCategories : _this.selectedCategories;
                officers = _this.selectedOfficers.length <= 0 ? _this.unfilteredOfficers : _this.selectedOfficers;
                if (_this.isShowingAllCategories()) {
                    _this.officerChartEntries = CustomBarChartService.customBarChartService.getCustomOfficersBarChartSummarizedData(officers, categories);
                }
                else {
                    _this.officerChartEntries = CustomBarChartService.customBarChartService.getCustomOfficersBarChartData(officers, categories);
                }
                if (_this.selectedOfficers.length <= 0) {
                    var officer = new Officer();
                    officer.shortFullName = "All Officers";
                    officer.id = -1;
                    categories = _this.isShowingAllCategories() ? null : _this.selectedCategories;
                    DashboardService.dashboardService.getCategoryAggregateForAllOfficers(_this.currentTimeFrame, categories).then(function (categories) {
                        officer.eventCategories = categories;
                        var categoriesForChart = _this.selectedCategories.length > 0 ? _this.selectedCategories : categories;
                        _this.categoryChartEntries = CustomBarChartService.customBarChartService.getCustomCategoryBarChartData([officer], categoriesForChart, false);
                    });
                }
                else {
                    var showZeroValues = !(_this.isShowingAllCategories());
                    _this.categoryChartEntries = CustomBarChartService.customBarChartService.getCustomCategoryBarChartData(officers, categories, showZeroValues);
                }
            };
            this.buildMap = function (events) {
                try {
                    _this.eventMap = new EventMap(events, _this.isShowingAllCategories());
                    _this.eventMap.build();
                }
                catch (ex) {
                }
            };
        }
        return SupervisorDashboard;
    })(FilterControlContainer);
    return SupervisorDashboard;
});
//# sourceMappingURL=dashboard.js.map