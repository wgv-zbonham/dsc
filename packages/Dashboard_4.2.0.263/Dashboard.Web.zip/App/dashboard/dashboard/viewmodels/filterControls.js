define(["require", "exports", 'durandal/app', "dashboard/models/timeFrame", "dashboard/models/constants", "dashboard/services/dashboardService", "dashboard/models/filterOptions", 'uiServices/notificationBuilder'], function (require, exports, app, TimeFrame, constants, DashboardService, FilterOptions, NotificationBuilder) {
    /// <amd-dependency path="chosenOrder"/>
    var ChosenOrder = require('chosenOrder');
    var FilterControl = (function () {
        function FilterControl() {
            var _this = this;
            this.selectedTimeFrame = TimeFrame.ThirtyDays;
            this.timeFrameOptions = [];
            this.availableCategories = [];
            this.selectedCategories = [];
            this.availableOfficers = []; //availableOfficers is used for the drop down
            this.selectedOfficers = [];
            this.defaultOfficersToShow = [];
            this.filterOptions = FilterOptions;
            this.appSubscriptions = [];
            this.officerCount = 0;
            this.MAX_OFFICERS_BEFORE_ASYNC = 250;
            this.filteredOfficers = []; //filteredOfficers are officers that show in custom officers widget
            //we can't rely on ko to maintain order of selected categories and officers, so we have to push them here when they are added or removed
            //from chosen multi select. This is most likely not a ko issue. I believe it is chosen itself that is the problem.
            this.orderedCategorieSelections = [];
            this.orderedOfficerSelections = [];
            this.activate = function (data) {
                _this.selectedTimeFrame = _this.filterOptions.getTimeFrame();
                _this.selectedCategories = _this.filterOptions.getCategories();
                _this.selectedOfficers = _this.filterOptions.getOfficers();
                //init ordered collections
                _this.orderedCategorieSelections = _this.selectedCategories;
                _this.orderedOfficerSelections = _this.selectedOfficers;
                _this.timeFrameOptions = [
                    { value: TimeFrame.SevenDays, text: "Last 7 Days" },
                    { value: TimeFrame.ThirtyDays, text: "Last 30 Days" },
                    { value: TimeFrame.TwelveMonths, text: "Last 12 Months" }
                ];
                _this.appSubscriptions.push(app.on(constants.DASBOARD_RELOAD_FILTER_CONTROL).then(function () {
                    _this.activate();
                }));
                _this.appSubscriptions.push(app.on(constants.DASHBOARD_OFFICER_WIDGET_OFFICER_CLICKED).then(function (officer) {
                    var selectedOfficer = _.findWhere(_this.filteredOfficers, { id: officer.id });
                    if (selectedOfficer) {
                        _this.filterOptions.setAvailableOfficers([selectedOfficer]);
                        window.location.href = "#dashboard/officerEvents?id=" + officer.id;
                    }
                    else {
                        console.log("Unable to find officer with id: " + officer.id);
                        NotificationBuilder.buildErrorToast("Unable to find the selected officer.");
                    }
                }));
                if (data) {
                    _this.officerCount = data.officerCount;
                    _this.availableOfficers = _this.isUsingOfficersTypeAhead() ? _this.filterOptions.getAvailableOfficers() : data.availableOfficers;
                    _this.availableCategories = data.availableCategories;
                    var officers = _this.getSelectedOfficers();
                    if (officers.length > 0) {
                        //anytime we make a call to api, we need reorder the officers so they are in correct order for graph.
                        data.officers = _this.getOrderedOfficers(data.officers);
                    }
                    _this.setFilteredOfficers(data.officers);
                    _this.defaultOfficersToShow = data.officers;
                    _this.filteredOfficersTotal = data.filteredOfficersTotal;
                    _this.filteredCategoriesTotal = data.filteredCategoriesTotal;
                    officers = _this.getSelectedOfficers();
                    var filterOptionsResult = {
                        selectedOfficers: officers.length > 0 ? _this.defaultOfficersToShow : [],
                        unfilteredOfficers: _this.defaultOfficersToShow,
                        selectedCategories: _this.getSelectedCategories(),
                        availableCategories: _this.availableCategories,
                        filteredOfficersTotal: _this.filteredOfficersTotal,
                        filteredCategoriesTotal: _this.filteredCategoriesTotal,
                        timeFrame: _this.selectedTimeFrame,
                        isCategoryFiltered: false,
                        isOfficerFiltered: false
                    };
                    app.trigger(constants.DASHBOARD_FILTER_OPTIONS_DATA_LOADED, filterOptionsResult);
                }
                DashboardService.dashboardService.attemptCookieRefresh();
            };
            this.compositionComplete = function () {
                _this.filterControlsLoaded();
            };
            this.detached = function () {
                _.forEach(_this.appSubscriptions, function (sub) { return sub.off(); });
                _this.appSubscriptions.length = 0;
            };
            this.timeFrameSelectionChanged = function () {
                _this.filterOptions.setTimeFrame(_this.selectedTimeFrame);
                _this.selectedTimeFrame = _this.filterOptions.getTimeFrame();
                DashboardService.dashboardService.getOfficerAggregateCatageorySummaries(_this.selectedTimeFrame, _this.selectedCategories, _this.selectedOfficers)
                    .then(function (data) {
                    _this.filteredOfficersTotal = data.officerCount;
                    _this.filteredCategoriesTotal = data.categoryCount;
                    _this.setFilteredOfficers(data.officers);
                    if (_this.isShowingAllOfficers(_this.selectedOfficers)) {
                        _this.defaultOfficersToShow = data.officers;
                        data.officers = [];
                    }
                    else {
                        data.officers = _this.getOrderedOfficers(data.officers);
                    }
                    var filterOptionsResult = {
                        selectedOfficers: data.officers,
                        unfilteredOfficers: _this.defaultOfficersToShow,
                        filteredOfficersTotal: _this.filteredOfficersTotal,
                        filteredCategoriesTotal: _this.filteredCategoriesTotal,
                        timeFrame: _this.selectedTimeFrame
                    };
                    app.trigger(constants.DASHBOARD_TIME_FRAME_CHANGED, filterOptionsResult);
                });
                return true;
            };
            this.categorySelectionChanged = function () {
                _this.filterOptions.setCategories(_this.selectedCategories);
                _this.selectedCategories = _this.filterOptions.getCategories();
                DashboardService.dashboardService.getOfficerAggregateCatageorySummaries(_this.selectedTimeFrame, _this.selectedCategories, _this.selectedOfficers)
                    .then(function (data) {
                    _this.filteredOfficersTotal = data.officerCount;
                    _this.filteredCategoriesTotal = data.categoryCount;
                    _this.setFilteredOfficers(data.officers);
                    if (_this.isShowingAllOfficers(_this.selectedOfficers)) {
                        _this.defaultOfficersToShow = data.officers;
                        data.officers = [];
                    }
                    else {
                        data.officers = _this.getOrderedOfficers(data.officers);
                    }
                    var filterOptionsResult = {
                        selectedOfficers: data.officers,
                        unfilteredOfficers: _this.defaultOfficersToShow,
                        selectedCategories: _this.getSelectedCategories(),
                        filteredOfficersTotal: _this.filteredOfficersTotal,
                        filteredCategoriesTotal: _this.filteredCategoriesTotal
                    };
                    app.trigger(constants.DASHBOARD_CATEGORY_SELECTION_CHANGED, filterOptionsResult);
                });
                return true;
            };
            this.officerSelectionChanged = function () {
                _this.filterOptions.setOfficers(_this.selectedOfficers);
                _this.selectedOfficers = _this.filterOptions.getOfficers();
                DashboardService.dashboardService.getOfficerAggregateCatageorySummaries(_this.selectedTimeFrame, _this.selectedCategories, _this.selectedOfficers)
                    .then(function (data) {
                    _this.filteredOfficersTotal = data.officerCount;
                    _this.filteredCategoriesTotal = data.categoryCount;
                    _this.setFilteredOfficers(data.officers);
                    if (_this.isShowingAllOfficers(_this.selectedOfficers)) {
                        _this.defaultOfficersToShow = data.officers;
                        data.officers = [];
                    }
                    else {
                        data.officers = _this.getOrderedOfficers(data.officers);
                    }
                    var filterOptionsResult = {
                        selectedOfficers: data.officers,
                        unfilteredOfficers: _this.defaultOfficersToShow,
                        filteredOfficersTotal: _this.filteredOfficersTotal,
                        filteredCategoriesTotal: _this.filteredCategoriesTotal
                    };
                    app.trigger(constants.DASHBOARD_OFFICER_SELECTION_CHANGED, filterOptionsResult);
                });
                return true;
            };
            this.isShowingAllOfficers = function (officers) {
                return (officers.length <= 0);
            };
            this.getSelectedOfficers = function () {
                if (_this.selectedOfficers) {
                    var officers = [];
                    _.each(_this.selectedOfficers, function (selectedOfficerId) {
                        var result = _.findWhere(_this.availableOfficers, { id: selectedOfficerId });
                        if (result) {
                            officers.push(result);
                        }
                    });
                    return officers;
                }
                else {
                    return null;
                }
            };
            this.getOrderedOfficers = function (officers) {
                //we are assuming we ordered this.selectedOfficers on the officer change event
                var orderedOfficers = [];
                _.each(_this.selectedOfficers, function (officerId) {
                    var officer = _.findWhere(officers, { id: officerId });
                    orderedOfficers.push(officer);
                });
                officers = orderedOfficers;
                return officers;
            };
            this.isUsingOfficersTypeAhead = function () {
                return _this.officerCount > _this.MAX_OFFICERS_BEFORE_ASYNC;
            };
            this.getSelectedCategories = function () {
                if (_this.selectedCategories) {
                    var categories = [];
                    _.each(_this.selectedCategories, function (selectedCategoryId) {
                        var result = _.findWhere(_this.availableCategories, { id: selectedCategoryId });
                        if (result) {
                            categories.push(result);
                        }
                    });
                    return categories;
                }
                else {
                    return null;
                }
            };
            this.setFilteredOfficers = function (officers) {
                //following supports ability to click on officer in dashboard 'Officers' custom widget and link to officer events
                var defaultOfficersCopy = [];
                _.each(officers, function (officer) {
                    //http://stackoverflow.com/questions/122102/what-is-the-most-efficient-way-to-clone-an-object
                    var officerCopy = $.extend(true, {}, officer);
                    delete officerCopy.eventCategories;
                    defaultOfficersCopy.push(officerCopy);
                });
                _this.filteredOfficers = defaultOfficersCopy;
            };
            this.filterControlsLoaded = function () {
                var chosenOptions = { max_selected_options: 3, allow_single_deselect: true, display_disabled_options: false };
                $('select#available-categories').chosen(chosenOptions);
                $('select#available-officers').chosen(chosenOptions);
                //NEED THE BELOW CODE TO ENSURE LOADED ORDER IS CORRECT
                ChosenOrder.setSelectionOrder($('select#available-categories'), _this.selectedCategories.map(String), true);
                ChosenOrder.setSelectionOrder($('select#available-officers'), _this.selectedOfficers.map(String), true);
                if (_this.isUsingOfficersTypeAhead()) {
                    _this.setupTypeAhead();
                }
                //must use chosen's change handler so we can maintain order of selected officers
                $('select#available-officers').on('change', function (evt, params) {
                    if (params.selected) {
                        _this.orderedOfficerSelections.push(parseInt(params.selected));
                    }
                    else if (params.deselected) {
                        var index = _this.orderedOfficerSelections.indexOf(parseInt(params.deselected));
                        _this.orderedOfficerSelections.splice(index, 1);
                    }
                    //allows us to maintain order, cannot trust selectedOfficers to keep order with ko bindings
                    _this.selectedOfficers = _this.orderedOfficerSelections;
                    if (_this.isUsingOfficersTypeAhead()) {
                        _this.filterOptions.setAvailableOfficers(ko.toJS(_this.getSelectedOfficers()));
                        _this.availableOfficers = _this.filterOptions.getAvailableOfficers();
                        $('select#available-officers').trigger('chosen:updated');
                    }
                    _this.officerSelectionChanged();
                });
                //must use chosen's change handler so we can maintain order of selected officers
                $('select#available-categories').on('change', function (evt, params) {
                    if (params.selected) {
                        _this.orderedCategorieSelections.push(parseInt(params.selected));
                    }
                    else if (params.deselected) {
                        var index = _this.orderedCategorieSelections.indexOf(parseInt(params.deselected));
                        _this.orderedCategorieSelections.splice(index, 1);
                    }
                    //allows us to maintain order, cannot trust selectedCategories to keep order with ko bindings
                    _this.selectedCategories = _this.orderedCategorieSelections;
                    _this.categorySelectionChanged();
                });
            };
            this.setupTypeAhead = function () {
                var isSearching = false;
                $('.available-officers .chosen-choices input').on('input', function () {
                    if (!isSearching) {
                        isSearching = true;
                        //using settimeout so that we don't make too many ajax calls. We are waiting half second before making ajax call.
                        setTimeout(function () {
                            var search = $('.available-officers .chosen-choices input').val();
                            if (search) {
                                DashboardService.dashboardService.getFilterOptions(search.toLowerCase())
                                    .then(function (data) {
                                    var officers = ko.toJS(_this.getSelectedOfficers()).concat(ko.toJS(data.officers));
                                    officers = _.uniq(officers, function (x) { return x.id; });
                                    _this.filterOptions.setAvailableOfficers(officers);
                                    _this.availableOfficers = officers;
                                    $('select#available-officers').trigger('chosen:updated');
                                    $('.available-officers .chosen-choices input').val(search);
                                });
                            }
                            isSearching = false;
                        }, 500);
                    }
                });
            };
        }
        return FilterControl;
    })();
    return FilterControl;
});
//# sourceMappingURL=filterControls.js.map