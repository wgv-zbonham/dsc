define(["require", "exports"], function (require, exports) {
    var FilteredStatistics = (function () {
        function FilteredStatistics() {
        }
        FilteredStatistics.prototype.activate = function (data) {
            this.statistics = data.activityTypeSummaries;
            this.isShowingBreakdowns = data.showBreakdowns;
        };
        FilteredStatistics.prototype.showUploadedBreakdown = function () {
            return this.isShowingBreakdowns && this.statistics.getUploadedTotal() > 0;
        };
        FilteredStatistics.prototype.showPlayedBreakdown = function () {
            return this.isShowingBreakdowns && this.statistics.getPlayedTotal() > 0;
        };
        FilteredStatistics.prototype.showExportedBreakdown = function () {
            return this.isShowingBreakdowns && this.statistics.getExportedTotal() > 0;
        };
        FilteredStatistics.prototype.showArchivedPurgedBreakdown = function () {
            return this.isShowingBreakdowns && this.statistics.getArchivedPurgedTotal() > 0;
        };
        return FilteredStatistics;
    })();
    return FilteredStatistics;
});
//# sourceMappingURL=filteredStatistics.js.map