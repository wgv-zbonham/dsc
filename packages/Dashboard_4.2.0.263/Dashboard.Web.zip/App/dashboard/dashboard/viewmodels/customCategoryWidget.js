define(["require", "exports"], function (require, exports) {
    var CustomCategoryWidget = (function () {
        function CustomCategoryWidget() {
            var _this = this;
            this.categoryChartEntries = [];
            this.activate = function (data) {
                _this.filteredCategoriesTotal = data.categoryTotal;
                _this.categoryChartEntries = data.chartEntries;
                _this.calculateTotalEvents();
            };
            this.hasCategoryChartEntries = function () {
                return _this.categoryChartEntries.length > 0;
            };
            this.categoryClicked = function (category) {
                window.location.href = "#dashboard/eventCategory?id=" + category.id;
            };
            this.showFooterMessage = function () {
                return _this.filteredCategoriesTotal > 0;
            };
        }
        CustomCategoryWidget.prototype.calculateTotalEvents = function () {
            var _this = this;
            this.totalEventsShown = 0;
            _.each(this.categoryChartEntries, function (entry) {
                _this.totalEventsShown = _this.totalEventsShown + entry.total;
            });
        };
        return CustomCategoryWidget;
    })();
    return CustomCategoryWidget;
});
//# sourceMappingURL=customCategoryWidget.js.map