define(["require", "exports"], function (require, exports) {
    var Test = (function () {
        function Test() {
        }
        Test.prototype.activate = function () {
            alert('activated');
        };
        return Test;
    })();
    return Test;
});
//# sourceMappingURL=test.js.map