define(["require", "exports"], function (require, exports) {
    var Dictionary = (function () {
        function Dictionary(init) {
            this._keys = new Array();
            for (var x = 0; x < init.length; x++) {
                this.add(init[x].key, init[x].value);
            }
        }
        Dictionary.prototype.add = function (key, value, overwrite) {
            if (!this.containsKey(key)) {
                this._keys.push(key);
            }
            if (typeof overwrite == 'undefined') {
                overwrite = true;
            }
            if (overwrite) {
                this[key] = value;
            }
        };
        Dictionary.prototype.remove = function (key) {
            var index = this._keys.indexOf(key, 0);
            this._keys.splice(index, 1);
            delete this[key];
        };
        Dictionary.prototype.keys = function () {
            return this._keys;
        };
        Dictionary.prototype.values = function () {
            var values = new Array();
            for (var key in this._keys)
                values.push(this[this._keys[key]]);
            return values;
        };
        Dictionary.prototype.containsKey = function (key) {
            if (typeof this[key] === 'undefined') {
                return false;
            }
            return true;
        };
        Dictionary.prototype.toLookup = function () {
            return this;
        };
        Dictionary.prototype.toJSON = function () {
            var map = {};
            for (var key in this._keys) {
                var value = this[this._keys[key]];
                map[this._keys[key]] = ko.viewmodel.toModel(value);
            }
            var result = ko.toJSON(map, function (k, v) {
                if (k == '__moduleId__')
                    return; // ignore the warning!
                return v;
            });
            return result;
        };
        return Dictionary;
    })();
    exports.Dictionary = Dictionary;
});
//# sourceMappingURL=dictionary.js.map