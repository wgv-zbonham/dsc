var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", 'models/dictionary'], function (require, exports, collections) {
    var viewTransitionStateBag = (function (_super) {
        __extends(viewTransitionStateBag, _super);
        function viewTransitionStateBag() {
            _super.apply(this, arguments);
            this._isSearchRequired = false;
            this._isShellComposed = false;
        }
        Object.defineProperty(viewTransitionStateBag.prototype, "isSearchRequired", {
            get: function () {
                return this._isSearchRequired;
            },
            set: function (value) {
                this._isSearchRequired = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(viewTransitionStateBag.prototype, "isShellComposed", {
            get: function () {
                return this._isShellComposed;
            },
            set: function (value) {
                this._isShellComposed = value;
            },
            enumerable: true,
            configurable: true
        });
        return viewTransitionStateBag;
    })(collections.Dictionary);
    exports.viewTransitionStateBag = viewTransitionStateBag;
    exports.stateBag = new viewTransitionStateBag([]);
});
//# sourceMappingURL=viewTransitionStateBag.js.map