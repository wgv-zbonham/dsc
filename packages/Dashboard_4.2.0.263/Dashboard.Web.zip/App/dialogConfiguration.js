﻿define(['plugins/dialog'], function(dialog) {
    return {
        configure: function () {
            //Here we are adding our own custom dialog context based on the default dialog context in durandal
            dialog.addContext('default', {
                blockoutOpacity: 0.2,
                removeDelay: 200,
                /**
                 * In this function, you are expected to add a DOM element to the tree which will serve as the "host" for the modal's composed view. You must add a property called host to the modalWindow object which references the dom element. It is this host which is passed to the composition module.
                 * @method addHost
                 * @param {Dialog} theDialog The dialog model.
                 */
                addHost: function (theDialog) {
                    var body = $('body');
                    var blockout = $('<div class="modal fade"></div>')
                        .css({ 'z-index': dialog.getNextZIndex(), 'opacity': this.blockoutOpacity })
                        .appendTo(body);

                    var host = $('<div class="modal-dialog"></div>')
                        .css({ 'z-index': dialog.getNextZIndex() })
                        .appendTo(body);

                    theDialog.host = host.get(0);
                    theDialog.blockout = blockout.get(0);

                    if (!dialog.isOpen()) {
                        theDialog.oldBodyMarginRight = body.css("margin-right");
                        theDialog.oldInlineMarginRight = body.get(0).style.marginRight;

                        var html = $("html");
                        var oldBodyOuterWidth = body.outerWidth(true);
                        var oldScrollTop = html.scrollTop();
                        $("html").css("overflow-y", "hidden");
                        var newBodyOuterWidth = $("body").outerWidth(true);
                        body.css("margin-right", (newBodyOuterWidth - oldBodyOuterWidth + parseInt(theDialog.oldBodyMarginRight, 10)) + "px");
                        html.scrollTop(oldScrollTop); // necessary for Firefox

                        //where vertical scroll bar appear, host must adjust its margin top, to make it always in
                        //visible area.
                        host.css('margin-top', $(document).scrollTop() + parseInt(host.css('margin-top'), 10));
                    }
                },
                /**
                 * This function is expected to remove any DOM machinery associated with the specified dialog and do any other necessary cleanup.
                 * @method removeHost
                 * @param {Dialog} theDialog The dialog model.
                 */
                removeHost: function (theDialog) {
                    $(theDialog.host).css('opacity', 0);
                    $(theDialog.blockout).css('opacity', 0);

                    setTimeout(function () {
                        ko.removeNode(theDialog.host);
                        ko.removeNode(theDialog.blockout);
                    }, this.removeDelay);

                    if (!dialog.isOpen()) {
                        var html = $("html");
                        var oldScrollTop = html.scrollTop(); // necessary for Firefox.
                        html.css("overflow-y", "").scrollTop(oldScrollTop);

                        if (theDialog.oldInlineMarginRight) {
                            $("body").css("margin-right", theDialog.oldBodyMarginRight);
                        } else {
                            $("body").css("margin-right", '');
                        }
                    }
                },
                attached: function (view) {
                    //To prevent flickering in IE8, we set visibility to hidden first, and later restore it
                    $(view).css("visibility", "hidden");
                },
                /**
                 * This function is called after the modal is fully composed into the DOM, allowing your implementation to do any final modifications, such as positioning or animation. You can obtain the original dialog object by using `getDialog` on context.model.
                 * @method compositionComplete
                 * @param {DOMElement} child The dialog view.
                 * @param {DOMElement} parent The parent view.
                 * @param {object} context The composition context.
                 */
                compositionComplete: function (child, parent, context) {
                    var theDialog = dialog.getDialog(context.model);
                    var $child = $(child);
                    var loadables = $child.find("img").filter(function () {
                        //Remove images with known width and height
                        var $this = $(this);
                        return !(this.style.width && this.style.height) && !($this.attr("width") && $this.attr("height"));
                    });

                    $child.data("predefinedWidth", $child.get(0).style.width);

                    var setDialogPosition = function (childView, objDialog) {
                        //Setting a short timeout is need in IE8, otherwise we could do this straight away
                        setTimeout(function () {
                            var $childView = $(childView);

                            objDialog.context.reposition(childView);

                            $(objDialog.host).css('opacity', 1);
                            $childView.css("visibility", "visible");

                            $childView.find('.autofocus').first().focus();
                        }, 1);
                    };

                    setDialogPosition(child, theDialog);
                    loadables.load(function () {
                        setDialogPosition(child, theDialog);
                    });

                    if ($child.hasClass('autoclose') || context.model.autoclose) {
                        $(theDialog.blockout).click(function () {
                            theDialog.close();
                        });
                    }
                },
                /**
                 * This function is called to reposition the model view.
                 * @method reposition
                 * @param {DOMElement} view The dialog view.
                 */
                reposition: function (view) {
                    var $view = $(view),
                        $window = $(window);

                    //We will clear and then set width for dialogs without width set 
                    if (!$view.data("predefinedWidth")) {
                        $view.css({ width: '' }); //Reset width
                    }
                    var width = $view.outerWidth(false),
                        height = $view.outerHeight(false),
                        windowHeight = $window.height() - 10, //leave at least 10 pixels free
                        windowWidth = $window.width() - 10, //leave at least 10 pixels free
                        constrainedHeight = Math.min(height, windowHeight),
                        constrainedWidth = Math.min(width, windowWidth);

                    $view.css({
                                       'margin-top': (-constrainedHeight / 2).toString() + 'px',
                        'margin-left': (-constrainedWidth / 2).toString() + 'px'
                    });

                    if (height > windowHeight) {
                        $view.css("overflow-y", "auto").outerHeight(windowHeight);
                    } else {
                        $view.css({
                            "overflow-y": "",
                            "height": ""
                        });
                    }

                    if (width > windowWidth) {
                        $view.css("overflow-x", "auto").outerWidth(windowWidth);
                    } else {
                        $view.css("overflow-x", "");

                        if (!$view.data("predefinedWidth")) {
                            //Ensure the correct width after margin-left has been set
                            $view.outerWidth(constrainedWidth);
                        } else {
                            $view.css("width", $view.data("predefinedWidth"));
                        }
                    }
                }
            });

            dialog.MessageBox.defaultViewMarkup = [
                '<div data-view="plugins/messageBox" data-bind="css: getClass(), style: getStyle()">',
                    '<div class="modal-header">',
                        '<h3 data-bind="html: title"></h3>',
                    '</div>',
                    '<div class="modal-body">',
                        '<p class="message" style="white-space:pre" data-bind="html: message"></p>',
                    '</div>',
                    '<div class="modal-footer">',
                        '<!-- ko foreach: options -->',
                        '<button data-bind="click: function () { $parent.selectOption($parent.getButtonValue($data)); }, text: $parent.getButtonText($data), css: $parent.getButtonClass($index)"></button>',
                        '<!-- /ko -->',
                        '<div style="clear:both;"></div>',
                    '</div>',
                '</div>'
            ].join('\n');
        }
    };
});